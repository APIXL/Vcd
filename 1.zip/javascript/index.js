/**
 * Gates of Olympus - Exact Landscape Edition
 * Pure Vanilla JavaScript ES6
 * Zero External Dependencies
 * Full AndroidBridge & Olivera Casino Integration
 */

(function () {
  'use strict';

  // --- SYMBOL CATALOG ---
  const SYMBOLS = [
    { id: 'scatter', name: 'Scatter Zeus', img: '/assets/img/scatter.svg', isScatter: true, basePayout: 100 },
    { id: 'crown', name: 'Mahkota Emas', img: '/assets/img/crown.svg', basePayout: 50 },
    { id: 'hourglass', name: 'Jam Pasir', img: '/assets/img/hourglass.svg', basePayout: 25 },
    { id: 'ring', name: 'Cincin Ruby', img: '/assets/img/ring.svg', basePayout: 15 },
    { id: 'chalice', name: 'Piala Olympus', img: '/assets/img/chalice.svg', basePayout: 12 },
    { id: 'gem_red', name: 'Batu Merah', img: '/assets/img/gem-red.svg', basePayout: 10 },
    { id: 'gem_purple', name: 'Batu Ungu', img: '/assets/img/gem-purple.svg', basePayout: 8 },
    { id: 'gem_yellow', name: 'Batu Kuning', img: '/assets/img/gem-yellow.svg', basePayout: 5 },
    { id: 'gem_green', name: 'Batu Hijau', img: '/assets/img/gem-green.svg', basePayout: 4 },
    { id: 'gem_blue', name: 'Batu Biru', img: '/assets/img/gem-blue.svg', basePayout: 2 }
  ];

  const MULTIPLIER_VALUES = [2, 3, 5, 10, 20, 30, 50, 100, 250, 500];

  const BET_LEVELS = [
    200, 400, 800, 1200, 2000, 5000, 10000, 20000, 30000, 50000, 100000, 250000, 500000, 1000000
  ];

  // --- GAME STATE ---
  const state = {
    playerId: 'PLAYER_GUEST',
    playerName: 'Player',
    playerLevel: 7,
    vipString: 'VIP3',
    vipLevel: 3,
    coins: 419306,
    jackpot: 52849200000,
    betIndex: 8, // 30,000 matches screenshot BET
    isSpinning: false,
    stopRequested: false,

    // Speed setting: 1X, 2X, 3X, 4X
    speedMultiplier: 1,

    // Sound & Vibration toggles
    soundEnabled: true,
    vibrationEnabled: true,

    // Auto Spin state
    autoSpinsRemaining: 0,

    // Free Spins State
    inFreeSpins: false,
    freeSpinsTotalAllocated: 0,
    freeSpinsRemaining: 0,
    freeSpinsTotalWin: 0,
    accumulatedGlobalMultiplier: 1,

    // Celebration Animated Popup State (Pauses spin until popup finishes or is skipped)
    celebrationActive: false,
    celebrationResolver: null,

    // Round Multiplier State (Top-Left Medallion starts at 1x)
    tumbleMultiplierSum: 1,
    currentTumbleWin: 0,
    currentRoundMultipliers: [],
    roundBreakdown: [],
    
    // 6 columns x 5 rows grid: indexed [col][row]
    board: []
  };

  // --- UTILS ---
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function formatNumber(num) {
    return Math.floor(num).toLocaleString('id-ID');
  }

  function formatShort(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return Math.floor(num / 1000) + 'K';
    return num.toString();
  }

  function getCurrentBet() {
    return BET_LEVELS[state.betIndex];
  }

  function triggerVibrate(ms = 40) {
    if (!state.vibrationEnabled) return;
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
        navigator.vibrate(ms);
      }
    } catch (_) {}
  }

  // --- PROCEDURAL WEB AUDIO SYNTHESIZER WITH ANDROID SOUNDPOOL BRIDGE ---
  const AudioFX = {
    ctx: null,

    init() {
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
          this.ctx = new AudioCtx();
        }
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    },

    playTone(freq, type = 'sine', duration = 0.1, gainVal = 0.15) {
      if (!state.soundEnabled) return;
      try {
        this.init();
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {}
    },

    playNativeOrWeb(sfxId, webFallbackFn) {
      if (state.soundEnabled && Bridge.has() && typeof window.AndroidBridge.playSfx === 'function') {
        try {
          window.AndroidBridge.playSfx(sfxId);
        } catch (_) {}
      }
      if (webFallbackFn) {
        webFallbackFn();
      }
    },

    spinTick() {
      this.playNativeOrWeb('spin', () => {
        this.playTone(320 + Math.random() * 80, 'triangle', 0.04, 0.08);
      });
    },

    buttonClick() {
      this.playNativeOrWeb('click', () => {
        this.playTone(440, 'triangle', 0.04, 0.1);
      });
    },

    tumbleExplode() {
      this.playNativeOrWeb('click', () => {
        this.playTone(200, 'sawtooth', 0.12, 0.18);
      });
    },

    winChime() {
      this.playNativeOrWeb('win', () => {
        this.playTone(523, 'triangle', 0.12, 0.15);
        setTimeout(() => this.playTone(659, 'triangle', 0.12, 0.18), 70);
        setTimeout(() => this.playTone(784, 'triangle', 0.18, 0.2), 140);
      });
    },

    scatterDing() {
      this.playNativeOrWeb('scatter', () => {
        this.playTone(880, 'sine', 0.25, 0.3);
        setTimeout(() => this.playTone(1174, 'sine', 0.35, 0.3), 100);
      });
    },

    thunderStrike() {
      this.playNativeOrWeb('coin', () => {
        try {
          this.init();
          if (!this.ctx) return;
          const bufferSize = this.ctx.sampleRate * 0.35;
          const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
          const data = buffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }
          const noise = this.ctx.createBufferSource();
          noise.buffer = buffer;
          const filter = this.ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(400, this.ctx.currentTime);
          filter.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.35);
          const gain = this.ctx.createGain();
          gain.gain.setValueAtTime(0.35, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);
          noise.connect(filter);
          filter.connect(gain);
          gain.connect(this.ctx.destination);
          noise.start();
        } catch (e) {}
      });
    },

    bigFanfare() {
      this.playNativeOrWeb('jackpot', () => {
        const notes = [523, 659, 784, 1046, 1318];
        notes.forEach((f, idx) => {
          setTimeout(() => this.playTone(f, 'sawtooth', 0.18, 0.15), idx * 90);
        });
      });
    },

    coinTick() {
      if (!state.soundEnabled) return;
      this.playTone(850 + Math.random() * 250, 'triangle', 0.04, 0.08);
    },

    celebrationCheer() {
      this.playNativeOrWeb('jackpot', () => {
        const chords = [523.25, 659.25, 783.99, 1046.5];
        chords.forEach((f, i) => {
          setTimeout(() => this.playTone(f, 'sawtooth', 0.28, 0.22), i * 85);
        });
      });
    }
  };

  // --- SAFE ANDROID BRIDGE INVOCATION HELPER ---
  const Bridge = {
    has() {
      return typeof window.AndroidBridge !== 'undefined' && window.AndroidBridge !== null;
    },
    call(methodName, ...args) {
      if (this.has() && typeof window.AndroidBridge[methodName] === 'function') {
        try {
          return window.AndroidBridge[methodName](...args);
        } catch (e) {
          console.warn('[AndroidBridge Error in ' + methodName + ']:', e);
          if (typeof window.AndroidBridge.onError === 'function') {
            try {
              window.AndroidBridge.onError(e.message || String(e));
            } catch (_) {}
          }
        }
      }
      return undefined;
    }
  };

  // --- DOM ELEMENTS REFERENCE (With Fallback IDs) ---
  const el = {
    get grid() { return document.getElementById('grid') || document.getElementById('matrix-grid'); },
    get playerChips() { return document.getElementById('player-chips'); },
    get betDisplay() { return document.getElementById('bet-display') || document.getElementById('bet-display-val'); },
    get winDisplay() { return document.getElementById('win-display') || document.getElementById('win-display-val'); },
    get jackpotDisplay() { return document.getElementById('jackpot-display'); },
    get tumbleWinVal() { return document.getElementById('tumble-win-val'); },
    get totalMultNum() { return document.getElementById('total-multiplier-number'); },
    get sisaFreeSpinBox() { return document.getElementById('sisa-freespin-box'); },
    get sisaFreeSpinVal() { return document.getElementById('sisa-freespin-val'); },
    get fsBadgeBtn() { return document.getElementById('fs-badge-btn'); },
    get fsFractionVal() { return document.getElementById('fs-fraction-val'); },
    get speedToggleBtn() { return document.getElementById('round-multiplier-pill'); },
    get speedValText() { return document.getElementById('round-multiplier-val'); },
    get spinBtn() { return document.getElementById('spin-btn') || document.getElementById('btn-spin-action'); },
    get autoSpinPopup() { return document.getElementById('auto-spin-popup'); },
    get tumbleBreakdownCard() { return document.getElementById('tumble-breakdown-card'); },
    get zeusFigureBox() { return document.getElementById('zeus-figure-box'); },
    get lightningFlash() { return document.getElementById('lightning-flash') || document.getElementById('screen-flash'); },
    get gameViewport() { return document.getElementById('game-viewport'); },

    // Modals, Celebration Popup, & Menu
    get topMenuDropdown() { return document.getElementById('top-menu-dropdown'); },
    get paytableModal() { return document.getElementById('paytable-modal'); },
    get betModal() { return document.getElementById('bet-modal'); },
    get chatModal() { return document.getElementById('chat-modal'); },
    get celebrationOverlay() { return document.getElementById('celebration-overlay') || document.getElementById('celebration-modal'); },
    get celebrationTitle() { return document.getElementById('celebration-title'); },
    get celebrationSubtitle() { return document.getElementById('celebration-subtitle'); },
    get celebrationEmblem() { return document.getElementById('celebration-emblem'); },
    get celebrationCardBox() { return document.getElementById('celebration-card-box'); },
    get celebrationAmount() { return document.getElementById('celebration-amount') || document.getElementById('celebration-val'); },
    get celebrationCoinsCanvas() { return document.getElementById('celebration-coins-canvas'); },
    get btnSkipCelebration() { return document.getElementById('btn-skip-celebration'); }
  };

  // --- BOARD INITIALIZATION ---
  function initBoard() {
    const gridEl = el.grid;
    if (!gridEl) return;
    gridEl.innerHTML = '';
    state.board = [];

    // 6 columns x 5 rows = 30 cells
    for (let col = 0; col < 6; col++) {
      state.board[col] = [];
      for (let row = 0; row < 5; row++) {
        const cell = document.createElement('div');
        cell.className = 'slot-cell';
        cell.dataset.col = col;
        cell.dataset.row = row;

        const sym = getRandomSymbol();
        const img = document.createElement('img');
        img.className = 'cell-symbol-img';
        img.src = sym.img;
        img.alt = sym.name;
        cell.appendChild(img);

        gridEl.appendChild(cell);

        state.board[col][row] = {
          el: cell,
          img: img,
          sym: sym,
          isOrb: false,
          mult: 0
        };
      }
    }
  }

  function hasMultiplierOnBoard() {
    if (!state.board || state.board.length === 0) return false;
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col] && state.board[col][row];
        if (item && item.isOrb) return true;
      }
    }
    return false;
  }

  function getRandomSymbol() {
    // Keseimbangan probabilitas: Jika ada multiplier di papan, gem dibuat susah tumble
    // (dispersi simbol diperluas, menghindari penumpukan 8+ simbol sejenis)
    if (hasMultiplierOnBoard()) {
      const counts = {};
      for (let col = 0; col < 6; col++) {
        for (let row = 0; row < 5; row++) {
          const item = state.board[col] && state.board[col][row];
          if (item && item.sym && !item.isOrb) {
            counts[item.sym.id] = (counts[item.sym.id] || 0) + 1;
          }
        }
      }
      const candidates = SYMBOLS.slice(1); // Simbol non-scatter
      // Prioritaskan simbol yang saat ini paling sedikit di papan agar tidak mudah mencapai 8+
      candidates.sort((a, b) => (counts[a.id] || 0) - (counts[b.id] || 0));
      const pool = candidates.slice(0, 4);
      return pool[Math.floor(Math.random() * pool.length)];
    }

    const r = Math.random();
    if (r < 0.035) return SYMBOLS[0]; // Scatter
    if (r < 0.10) return SYMBOLS[1];  // Crown
    if (r < 0.20) return SYMBOLS[2];  // Hourglass
    if (r < 0.32) return SYMBOLS[3];  // Ring
    if (r < 0.44) return SYMBOLS[4];  // Chalice
    if (r < 0.56) return SYMBOLS[5];  // Gem Red
    if (r < 0.68) return SYMBOLS[6];  // Gem Purple
    if (r < 0.79) return SYMBOLS[7];  // Gem Yellow
    if (r < 0.89) return SYMBOLS[8];  // Gem Green
    return SYMBOLS[9];                // Gem Blue
  }

  // --- UI UPDATERS (updateDisplays) ---
  function updateDisplays() {
    if (el.playerChips) el.playerChips.textContent = formatNumber(state.coins);
    if (el.betDisplay) el.betDisplay.textContent = formatNumber(getCurrentBet());
    if (el.jackpotDisplay) el.jackpotDisplay.textContent = formatNumber(state.jackpot);
    if (el.tumbleWinVal) el.tumbleWinVal.textContent = formatNumber(state.currentTumbleWin);

    // 1. Total Multiplier Medallion in top-left:
    // When no tumble has occurred, default is 1x. During tumble it shows the sum (e.g. 25 + 10 = 35x).
    const displayMult = state.inFreeSpins ? state.accumulatedGlobalMultiplier : state.tumbleMultiplierSum;
    if (el.totalMultNum) el.totalMultNum.textContent = displayMult + 'x';

    // 2. Free Spin Counters and Conditional Visibility:
    // Hidden in base game, displayed ONLY when in Free Spins mode!
    if (state.inFreeSpins) {
      if (el.sisaFreeSpinBox) el.sisaFreeSpinBox.style.display = 'block';
      if (el.fsBadgeBtn) el.fsBadgeBtn.style.display = 'flex';
      if (el.sisaFreeSpinVal) el.sisaFreeSpinVal.textContent = state.freeSpinsRemaining;
      if (el.fsFractionVal) el.fsFractionVal.textContent = (state.freeSpinsTotalAllocated - state.freeSpinsRemaining) + '/' + state.freeSpinsTotalAllocated;
    } else {
      if (el.sisaFreeSpinBox) el.sisaFreeSpinBox.style.display = 'none';
      if (el.fsBadgeBtn) el.fsBadgeBtn.style.display = 'none';
    }

    // 3. Speed toggle button next to spin (1X -> 2X -> 3X -> 4X)
    if (el.speedValText) el.speedValText.textContent = state.speedMultiplier + 'X';
    if (el.speedToggleBtn) {
      if (state.speedMultiplier > 1) {
        el.speedToggleBtn.classList.add('speed-boosted');
      } else {
        el.speedToggleBtn.classList.remove('speed-boosted');
      }
    }

    // 4. Spin action button state (SPIN / STOP or Auto remaining)
    if (el.spinBtn) {
      if (state.isSpinning) {
        if (state.autoSpinsRemaining > 0) {
          const autoTxt = state.autoSpinsRemaining > 100000 ? '∞' : state.autoSpinsRemaining;
          el.spinBtn.textContent = 'STOP (' + autoTxt + ')';
        } else {
          el.spinBtn.textContent = 'STOP';
        }
        el.spinBtn.classList.add('is-stop');
      } else {
        if (state.autoSpinsRemaining > 0) {
          const autoTxt = state.autoSpinsRemaining > 100000 ? '∞' : state.autoSpinsRemaining;
          el.spinBtn.textContent = 'AUTO (' + autoTxt + ')';
        } else {
          el.spinBtn.textContent = 'SPIN';
        }
        el.spinBtn.classList.remove('is-stop');
      }
    }
  }

  function renderBreakdown() {
    const card = el.tumbleBreakdownCard;
    if (!card) return;

    if (state.roundBreakdown.length === 0) {
      card.innerHTML = `
        <div class="breakdown-row" style="color: #94a3b8; font-size: 8px; justify-content: center;">
          MENUNGGU TUMBLE...
        </div>`;
      return;
    }

    card.innerHTML = '';
    const recent = state.roundBreakdown.slice(-3);
    recent.forEach(item => {
      const row = document.createElement('div');
      row.className = 'breakdown-row';
      row.innerHTML = `
        <span class="breakdown-item-info">
          <span class="breakdown-count">${item.count}</span>
          <img src="${item.sym.img}" class="breakdown-icon" alt="${item.sym.name}" />
        </span>
        <span class="breakdown-payout">${formatShort(item.payout)}</span>
      `;
      card.appendChild(row);
    });
  }

  // --- SPEED TOGGLE (1X -> 2X -> 3X -> 4X) ---
  function cycleSpeed() {
    AudioFX.spinTick();
    triggerVibrate(30);
    state.speedMultiplier = (state.speedMultiplier % 4) + 1;
    updateDisplays();
  }

  // --- BET ADJUSTER ---
  function adjustBet(dir) {
    if (state.isSpinning) return;
    AudioFX.spinTick();
    triggerVibrate(25);
    state.betIndex += dir;
    if (state.betIndex < 0) state.betIndex = 0;
    if (state.betIndex >= BET_LEVELS.length) state.betIndex = BET_LEVELS.length - 1;
    updateDisplays();
  }

  function openBetModal() {
    if (state.isSpinning) return;
    const grid = document.getElementById('bet-options-grid');
    if (grid) {
      grid.innerHTML = '';
      BET_LEVELS.forEach((bet, idx) => {
        const btn = document.createElement('button');
        btn.className = 'bet-tile-btn' + (idx === state.betIndex ? ' selected' : '');
        btn.textContent = formatNumber(bet);
        btn.onclick = () => {
          state.betIndex = idx;
          updateDisplays();
          closeModal('bet-modal');
        };
        grid.appendChild(btn);
      });
    }
    if (el.betModal) el.betModal.style.display = 'flex';
  }

  function addDemoCoins() {
    AudioFX.winChime();
    triggerVibrate(40);
    state.coins += 5000000;
    Bridge.call('updateCoins', 5000000);
    updateDisplays();
  }

  // --- AUTO SPIN LONG PRESS & POPUP ---
  let spinLongPressTimer = null;
  let isLongPressTriggered = false;

  function bindSpinLongPress() {
    const btn = el.spinBtn;
    if (!btn) return;

    const onPointerDown = () => {
      if (state.isSpinning) return;
      isLongPressTriggered = false;
      spinLongPressTimer = setTimeout(() => {
        isLongPressTriggered = true;
        toggleAutoSpinPopup(true);
      }, 450);
    };

    const onPointerUp = () => {
      if (spinLongPressTimer) {
        clearTimeout(spinLongPressTimer);
        spinLongPressTimer = null;
      }
    };

    btn.addEventListener('mousedown', onPointerDown);
    btn.addEventListener('touchstart', onPointerDown, { passive: true });

    btn.addEventListener('mouseup', onPointerUp);
    btn.addEventListener('mouseleave', onPointerUp);
    btn.addEventListener('touchend', onPointerUp);
    btn.addEventListener('touchcancel', onPointerUp);
  }

  function toggleAutoSpinPopup(show = null) {
    const popup = el.autoSpinPopup;
    if (!popup) return;
    const shouldShow = (show !== null) ? show : (popup.style.display === 'none');
    popup.style.display = shouldShow ? 'flex' : 'none';
    if (shouldShow) {
      AudioFX.spinTick();
      triggerVibrate(40);
    }
  }

  function selectAutoSpin(count) {
    toggleAutoSpinPopup(false);
    AudioFX.spinTick();
    triggerVibrate(40);
    state.autoSpinsRemaining = count;
    executeSpin();
  }

  // --- MAIN SPIN ACTION (SPIN / STOP) ---
  function handleSpinAction() {
    AudioFX.init();

    // If celebration popup is showing, clicking spin skips and dismisses it immediately
    if (state.celebrationActive) {
      skipCelebration();
      return;
    }

    if (isLongPressTriggered) {
      isLongPressTriggered = false;
      return;
    }

    // If auto-spin is running, clicking cancels it
    if (state.autoSpinsRemaining > 0) {
      state.autoSpinsRemaining = 0;
      state.stopRequested = true;
      updateDisplays();
      return;
    }

    // If reels are spinning, clicking requests instant stop
    if (state.isSpinning) {
      state.stopRequested = true;
      return;
    }

    executeSpin();
  }

  async function executeSpin(isBonusSpin = false) {
    if (state.isSpinning || state.celebrationActive) return;

    const bet = getCurrentBet();
    if (!isBonusSpin && !state.inFreeSpins) {
      if (state.coins < bet) {
        state.autoSpinsRemaining = 0;
        alert('Chip Anda tidak cukup untuk memasang taruhan!');
        updateDisplays();
        return;
      }
      state.coins -= bet;
      state.jackpot += Math.floor(bet * 0.03);

      // AndroidBridge: onSpinStart & onBet
      Bridge.call('onSpinStart');
      Bridge.call('onBet', bet);
      Bridge.call('updateCoins', -bet);
    }

    state.isSpinning = true;
    state.stopRequested = false;
    state.currentTumbleWin = 0;
    state.currentRoundMultipliers = [];
    state.roundBreakdown = [];
    
    // In base game: reset tumble multiplier to 1x at start of spin
    if (!state.inFreeSpins) {
      state.tumbleMultiplierSum = 1;
    }

    if (el.winDisplay) el.winDisplay.textContent = '0';
    renderBreakdown();
    updateDisplays();

    // 1. Reel spinning roll (delays scale with speedMultiplier)
    await runSpinAnimation();

    // 2. Chance of Zeus Lightning Strike summoning Winged Multiplier Orbs
    const zeusChance = state.inFreeSpins ? 0.5 : 0.3;
    if (Math.random() < zeusChance) {
      await triggerZeusLightning();
    }

    // 3. Tumble Cascade Loop (Evaluate 8+ clusters, explode, drop, repeat)
    let hasWins = false;
    let anyWinInRound = false;
    do {
      hasWins = await evaluateClusters();
      if (hasWins) {
        anyWinInRound = true;
        // Chance of Zeus lightning strike summoning more multiplier orbs during tumble!
        const midTumbleZeusChance = state.inFreeSpins ? 0.35 : 0.20;
        if (Math.random() < midTumbleZeusChance && !state.stopRequested) {
          await triggerZeusLightning();
        }
      }
      if (state.stopRequested) break;
    } while (hasWins);

    // 4. Multiply Tumble Win by Multiplier Orbs gathered during tumble!
    if (anyWinInRound && state.currentRoundMultipliers.length > 0) {
      AudioFX.thunderStrike();

      if (state.inFreeSpins) {
        // In free spins, accumulated global multiplier grows
        state.accumulatedGlobalMultiplier += (state.tumbleMultiplierSum > 1 ? state.tumbleMultiplierSum : 1);
        updateDisplays();
      }

      const multToApply = state.inFreeSpins ? state.accumulatedGlobalMultiplier : state.tumbleMultiplierSum;
      const totalWinCalculated = state.currentTumbleWin * multToApply;
      state.currentTumbleWin = totalWinCalculated;
      if (el.tumbleWinVal) el.tumbleWinVal.textContent = formatNumber(state.currentTumbleWin);
      if (el.winDisplay) el.winDisplay.textContent = formatNumber(state.currentTumbleWin);
    }

    // 5. Finalize Round Payout & Bridge callbacks
    if (state.currentTumbleWin > 0) {
      const MAX_WIN_CAP = bet * 5000;
      let hitMaxWin = false;

      // Di dalam mode Free Spin, periksa batas MAX WIN (5.000x taruhan)
      if (state.inFreeSpins) {
        if ((state.freeSpinsTotalWin + state.currentTumbleWin) >= MAX_WIN_CAP) {
          hitMaxWin = true;
          state.currentTumbleWin = Math.max(0, MAX_WIN_CAP - state.freeSpinsTotalWin);
          state.freeSpinsTotalWin = MAX_WIN_CAP;
          state.coins += state.currentTumbleWin;
        } else {
          state.coins += state.currentTumbleWin;
          state.freeSpinsTotalWin += state.currentTumbleWin;
        }
      } else {
        state.coins += state.currentTumbleWin;
      }

      if (el.winDisplay) el.winDisplay.textContent = formatNumber(state.inFreeSpins ? state.freeSpinsTotalWin : state.currentTumbleWin);

      // AndroidBridge: onWin & updateCoins
      Bridge.call('onWin', state.currentTumbleWin);
      Bridge.call('updateCoins', state.currentTumbleWin);

      // JIKA MENDAPATKAN MAXWIN DIDALAM MODE FREESPIN:
      // Langsung hentikan freespin berapapun sisanya dan tampilkan popup kemenangan freespin yang didapat dari maxwin tersebut!
      if (hitMaxWin) {
        state.freeSpinsRemaining = 0;
        state.inFreeSpins = false;
        state.isSpinning = false;
        state.stopRequested = false;
        state.tumbleMultiplierSum = 1;
        updateDisplays();

        const maxWinTier = {
          title: 'MAX WIN!',
          subtitle: 'KEMENANGAN MAKSIMAL 5.000X TERCAPAI! SISA FREE SPIN DIHENTIKAN',
          emblem: '⚡',
          tierClass: 'tier-max'
        };
        await showCelebrationModal(state.freeSpinsTotalWin, maxWinTier);
        state.freeSpinsTotalWin = 0;
        updateDisplays();
        return;
      }

      // Check celebration tiers: Big Win, Mega Win, Super Win, Epic Win, Massive Win, Max Win
      const celebrationTier = determineCelebrationTier(state.currentTumbleWin, false);
      if (celebrationTier) {
        // PAUSE SPIN EXECUTION UNTIL POPUP FINISHES OR USER CLICKS SKIP IN BOTTOM-RIGHT CORNER!
        await showCelebrationModal(state.currentTumbleWin, celebrationTier);
      } else {
        AudioFX.winChime();
      }
    } else {
      // AndroidBridge: onLose if no win
      Bridge.call('onLose', bet);
    }

    // AndroidBridge: onSpinEnd
    Bridge.call('onSpinEnd');

    // 6. Check for Free Spins Trigger (4+ Zeus Scatters)
    await checkScatterBonus();

    // 7. Finish Spin & Reset Tumble Multiplier in base game
    state.isSpinning = false;
    state.stopRequested = false;

    // Reset base game tumble multiplier back to 1x when round completes
    if (!state.inFreeSpins) {
      state.tumbleMultiplierSum = 1;
    }
    updateDisplays();

    // If currently in Free Spins, continue to next spin!
    if (state.inFreeSpins) {
      state.freeSpinsRemaining--;
      updateDisplays();
      if (state.freeSpinsRemaining > 0) {
        const nextDelay = Math.max(150, Math.floor(650 / state.speedMultiplier));
        setTimeout(() => executeSpin(true), nextDelay);
      } else {
        state.inFreeSpins = false;
        updateDisplays();
        // Selesai Free Spin Popup: PAUSES SPIN UNTIL POPUP FINISHES OR IS SKIPPED!
        const fsTier = determineCelebrationTier(state.freeSpinsTotalWin, true, state.freeSpinsTotalAllocated || 10);
        await showCelebrationModal(state.freeSpinsTotalWin, fsTier);
        state.freeSpinsTotalWin = 0;
      }
      return;
    }

    // If Auto Spin is active, proceed to next spin
    if (state.autoSpinsRemaining > 0) {
      if (state.autoSpinsRemaining < 900000) {
        state.autoSpinsRemaining--;
      }
      if (state.autoSpinsRemaining > 0 && !state.stopRequested) {
        const autoDelay = Math.max(120, Math.floor(450 / state.speedMultiplier));
        setTimeout(() => executeSpin(), autoDelay);
      } else {
        state.autoSpinsRemaining = 0;
        updateDisplays();
      }
    }
  }

  // --- MULTIPLIER ORB HELPERS ---
  function getBadgeColorClass(mult) {
    if (mult <= 5) return 'badge-green';
    if (mult <= 25) return 'badge-blue';
    if (mult <= 100) return 'badge-purple';
    return 'badge-gold';
  }

  function spawnOrbOnItem(item, multVal) {
    item.isOrb = true;
    item.mult = multVal;
    item.sym = { id: 'multiplier-orb', name: 'Multiplier ' + multVal + 'X', isScatter: false, basePayout: 0 };
    item.img.src = '/assets/img/winged-orb.svg';
    item.img.alt = 'Multiplier ' + multVal + 'X';
    item.img.style.visibility = 'visible';
    item.el.classList.add('orb-cell');
    item.el.classList.remove('win-highlight', 'exploding', 'empty-drop-out');

    const existingBadge = item.el.querySelector('.orb-badge-tag');
    if (existingBadge) existingBadge.remove();

    const badge = document.createElement('span');
    badge.className = 'orb-badge-tag ' + getBadgeColorClass(multVal);
    badge.textContent = multVal + 'X';
    item.el.appendChild(badge);

    // Bergetar HANYA saat mendapatkan x100 atau diatasnya (x100, x250, x500)
    if (multVal >= 100) {
      triggerVibrate(250);
      Bridge.call('vibratePhone', 250);
      if (el.gameViewport) {
        el.gameViewport.classList.add('shake-screen');
        setTimeout(() => el.gameViewport && el.gameViewport.classList.remove('shake-screen'), 350);
      }
    }

    // Accumulate into tumbleMultiplierSum (e.g. 25 + 10 = 35x)
    if (state.tumbleMultiplierSum === 1) {
      state.tumbleMultiplierSum = multVal;
    } else {
      state.tumbleMultiplierSum += multVal;
    }
    state.currentRoundMultipliers.push(multVal);
    updateDisplays();
  }

  function setCellSymbol(item, sym) {
    item.sym = sym;
    item.isOrb = false;
    item.mult = 0;
    item.img.src = sym.img;
    item.img.alt = sym.name;
    item.img.style.visibility = 'visible';
    item.el.className = 'slot-cell';
    const existingBadge = item.el.querySelector('.orb-badge-tag');
    if (existingBadge) existingBadge.remove();
  }

  // --- SPIN ANIMATION: EMPTY OUT ALL GEMS, THEN CASCADE DROP ALL NEW GEMS ---
  async function runSpinAnimation() {
    // Stage 1: Buat semua kosong (All gems slide/drop down out of the grid)
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        item.el.classList.remove('win-highlight', 'exploding', 'spin-cascade-drop', 'tumble-drop');
        item.el.classList.add('empty-drop-out');
      }
    }
    AudioFX.spinTick();

    const emptyDelay = state.stopRequested ? 40 : Math.max(50, Math.floor(130 / state.speedMultiplier));
    await sleep(emptyDelay);

    // Set all cells to blank / empty grid (semua kosong)
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        item.el.className = 'slot-cell is-empty-grid';
        item.img.style.visibility = 'hidden';
        item.isOrb = false;
        item.mult = 0;
        const badge = item.el.querySelector('.orb-badge-tag');
        if (badge) badge.remove();
      }
    }

    const emptyPause = state.stopRequested ? 20 : Math.max(30, Math.floor(75 / state.speedMultiplier));
    await sleep(emptyPause);

    // Stage 2: Semua gem terjatuh (All new gems fall into the grid column by column)
    const colStagger = state.stopRequested ? 0 : Math.max(15, Math.floor(38 / state.speedMultiplier));

    for (let col = 0; col < 6; col++) {
      if (state.stopRequested) {
        // Instant drop for all remaining columns if stop was requested
        for (let c = col; c < 6; c++) {
          for (let row = 0; row < 5; row++) {
            const item = state.board[c][row];
            const sym = getRandomSymbol();
            setCellSymbol(item, sym);
            item.el.className = 'slot-cell spin-cascade-drop';
          }
        }
        AudioFX.spinTick();
        break;
      }

      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        const sym = getRandomSymbol();
        setCellSymbol(item, sym);
        item.el.className = 'slot-cell spin-cascade-drop';
      }
      AudioFX.spinTick();
      if (colStagger > 0) {
        await sleep(colStagger);
      }
    }

    const settleDelay = state.stopRequested ? 50 : Math.max(60, Math.floor(200 / state.speedMultiplier));
    await sleep(settleDelay);

    // Clean up animation classes to normal slot-cell
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        state.board[col][row].el.className = 'slot-cell';
      }
    }
  }

  // --- ZEUS LIGHTNING STRIKE ---
  async function triggerZeusLightning(forcedMultiplier = null) {
    if (el.zeusFigureBox) el.zeusFigureBox.classList.add('is-casting');
    if (el.lightningFlash) el.lightningFlash.style.opacity = '0.9';
    if (el.gameViewport) el.gameViewport.classList.add('shake-screen');
    AudioFX.thunderStrike();

    const flashDelay = Math.max(25, Math.floor(90 / state.speedMultiplier));
    await sleep(flashDelay);
    if (el.lightningFlash) el.lightningFlash.style.opacity = '0';
    setTimeout(() => {
      if (el.zeusFigureBox) el.zeusFigureBox.classList.remove('is-casting');
      if (el.gameViewport) el.gameViewport.classList.remove('shake-screen');
    }, 250);

    const multVal = forcedMultiplier || MULTIPLIER_VALUES[Math.floor(Math.random() * MULTIPLIER_VALUES.length)];

    // Target a non-orb candidate cell
    const nonOrbCells = [];
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const c = state.board[col][row];
        if (!c.isOrb) {
          nonOrbCells.push(c);
        }
      }
    }

    if (nonOrbCells.length > 0) {
      const targetItem = nonOrbCells[Math.floor(Math.random() * nonOrbCells.length)];
      spawnOrbOnItem(targetItem, multVal);
    }
  }

  // --- EVALUATE CLUSTERS & TUMBLE CASCADE (Speed Multiplier Scaled) ---
  async function evaluateClusters() {
    const symbolCounts = {};
    const symbolPositions = {};

    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        // MULTIPLIER ORB TIDAK DIHITUNG DALAM KOMBINASI PECAH BIASA
        if (!item.isOrb && item.sym && !item.sym.isScatter && item.sym.id !== 'multiplier-orb') {
          const id = item.sym.id;
          symbolCounts[id] = (symbolCounts[id] || 0) + 1;
          if (!symbolPositions[id]) symbolPositions[id] = [];
          symbolPositions[id].push({ col, row });
        }
      }
    }

    // Find symbols with >= 8 items
    const winningIds = Object.keys(symbolCounts).filter(id => symbolCounts[id] >= 8);
    if (winningIds.length === 0) {
      return false;
    }

    let cascadeSubtotal = 0;
    const bet = getCurrentBet();

    winningIds.forEach(id => {
      const count = symbolCounts[id];
      const sym = SYMBOLS.find(s => s.id === id);

      let tierMultiplier = 1.0;
      if (count >= 12) tierMultiplier = 3.2;
      else if (count >= 10) tierMultiplier = 1.8;

      const payout = Math.floor(bet * (sym.basePayout / 40) * tierMultiplier);
      cascadeSubtotal += payout;

      // Log into Breakdown
      state.roundBreakdown.push({ count, sym, payout });

      // Highlight winning cells (Multiplier Orb tidak ikut di-highlight)
      symbolPositions[id].forEach(pos => {
        const cellItem = state.board[pos.col][pos.row];
        if (!cellItem.isOrb) {
          cellItem.el.classList.add('win-highlight');
        }
      });
    });

    state.currentTumbleWin += cascadeSubtotal;
    if (el.tumbleWinVal) el.tumbleWinVal.textContent = formatNumber(state.currentTumbleWin);
    renderBreakdown();
    AudioFX.winChime();
    triggerVibrate(35);

    const highlightDelay = state.stopRequested ? 80 : Math.max(90, Math.floor(450 / state.speedMultiplier));
    await sleep(highlightDelay);

    // Explode winning cells (MULTIPLIER ORB TIDAK IKUT PECAH!)
    winningIds.forEach(id => {
      symbolPositions[id].forEach(pos => {
        const cellItem = state.board[pos.col][pos.row];
        if (!cellItem.isOrb) {
          cellItem.el.classList.add('exploding');
        }
      });
    });

    AudioFX.tumbleExplode();
    const explodeDelay = state.stopRequested ? 60 : Math.max(70, Math.floor(300 / state.speedMultiplier));
    await sleep(explodeDelay);

    // Column gravity drop:
    // Multiplier orbs yang didapat pada saat tumble TIDAK IKUT PECAH melainkan TETAP DISITU (turun mengikuti gravitasi jika cell bawahnya kosong)
    for (let col = 0; col < 6; col++) {
      const survivors = [];
      for (let row = 4; row >= 0; row--) {
        const item = state.board[col][row];
        // Multiplier orb SELALU BERTAHAN / TIDAK PECAH
        if (item.isOrb || !item.el.classList.contains('exploding')) {
          survivors.push({
            sym: item.sym,
            isOrb: item.isOrb,
            mult: item.mult
          });
        }
      }

      for (let row = 4; row >= 0; row--) {
        const item = state.board[col][row];
        item.el.className = 'slot-cell tumble-drop';
        const existingBadge = item.el.querySelector('.orb-badge-tag');
        if (existingBadge) existingBadge.remove();

        const sIdx = 4 - row;
        if (sIdx < survivors.length) {
          const s = survivors[sIdx];
          item.sym = s.sym;
          item.isOrb = s.isOrb;
          item.mult = s.mult;
          item.img.src = s.isOrb ? '/assets/img/winged-orb.svg' : s.sym.img;
          item.img.alt = s.isOrb ? ('Multiplier ' + s.mult + 'X') : s.sym.name;
          item.img.style.visibility = 'visible';

          // Jika simbol yang bertahan adalah Multiplier Orb, pertahankan status dan badge orb-nya!
          if (s.isOrb) {
            item.el.classList.add('orb-cell');
            const b = document.createElement('span');
            b.className = 'orb-badge-tag ' + getBadgeColorClass(s.mult);
            b.textContent = s.mult + 'X';
            item.el.appendChild(b);
          }
        } else {
          // New symbol drops from above to fill empty space
          // Multiplier lebih susah didapat terutama jika gem pecah (tumble)
          const orbDropChance = state.inFreeSpins ? 0.02 : 0.008;
          if (Math.random() < orbDropChance) {
            const multVal = MULTIPLIER_VALUES[Math.floor(Math.random() * MULTIPLIER_VALUES.length)];
            spawnOrbOnItem(item, multVal);
          } else {
            const newSym = getRandomSymbol();
            setCellSymbol(item, newSym);
          }
        }
      }
    }

    const dropDelay = state.stopRequested ? 80 : Math.max(80, Math.floor(320 / state.speedMultiplier));
    await sleep(dropDelay);
    return true;
  }

  // --- POPUP FREESPIN 10 (Overlay saat mendapatkan 4+ Scatter) ---
  let freespinIntroResolver = null;

  function showFreeSpinsIntroModal(count = 10) {
    return new Promise(resolve => {
      freespinIntroResolver = resolve;
      state.celebrationActive = true;
      AudioFX.bigFanfare();

      const overlay = document.getElementById('freespin-intro-overlay');
      if (overlay) {
        overlay.style.display = 'flex';
      }
      triggerFreeSpins(count);
    });
  }

  function startFreeSpinsFromPopup() {
    AudioFX.buttonClick();
    const overlay = document.getElementById('freespin-intro-overlay');
    if (overlay) {
      overlay.style.display = 'none';
    }
    state.celebrationActive = false;

    if (typeof freespinIntroResolver === 'function') {
      const res = freespinIntroResolver;
      freespinIntroResolver = null;
      res();
    }
  }

  // --- SCATTER CHECK ---
  async function checkScatterBonus() {
    let scatters = 0;
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        if (state.board[col][row].sym && state.board[col][row].sym.isScatter) {
          scatters++;
        }
      }
    }

    if (scatters >= 4) {
      AudioFX.scatterDing();
      const bet = getCurrentBet();
      let bonusPayout = bet * (scatters === 4 ? 3 : (scatters === 5 ? 5 : 100));
      state.coins += bonusPayout;
      updateDisplays();

      if (state.inFreeSpins) {
        state.freeSpinsRemaining += 5;
        state.freeSpinsTotalAllocated += 5;
        updateDisplays();
        alert('⚡ RETRIGGER! +5 FREE SPIN DITAMBAHKAN! ⚡');
      } else {
        // Tampilkan POPUP FREESPIN 10 saat mendapatkan scatter!
        await showFreeSpinsIntroModal(10);
      }
    }
  }

  function triggerFreeSpins(count = 10) {
    state.inFreeSpins = true;
    state.freeSpinsTotalAllocated = count;
    state.freeSpinsRemaining = count;
    state.freeSpinsTotalWin = 0;
    state.accumulatedGlobalMultiplier = 1;
    state.tumbleMultiplierSum = 1;
    updateDisplays();

    Bridge.call('onFreeSpinsTriggered', count);
  }

  function buyFreeSpinsDirect() {
    if (state.isSpinning) return;
    const cost = getCurrentBet() * 100;
    if (state.coins < cost) {
      alert('Chip Anda tidak cukup untuk Membeli Free Spin (Perlu ' + formatNumber(cost) + ' Chip)!');
      return;
    }
    if (confirm('Beli 10 Free Spin seharga ' + formatNumber(cost) + ' Chip?')) {
      state.coins -= cost;
      Bridge.call('onBet', cost);
      Bridge.call('updateCoins', -cost);
      showFreeSpinsIntroModal(10);
      executeSpin(true);
    }
  }

  // =========================================================================
  // CELEBRATION TIERS & ANIMATED POPUP ENGINE
  // (Big Win, Mega Win, Super Win, Epic Win, Massive Win, Max Win, Selesai Free Spin)
  // =========================================================================

  function determineCelebrationTier(amount, isFreeSpinEnd = false, freeSpinRounds = 0) {
    if (isFreeSpinEnd) {
      return {
        title: 'SELESAI FREE SPIN!',
        subtitle: 'TOTAL KEMENANGAN ' + (freeSpinRounds || 10) + ' PUTARAN',
        emblem: '🏛️',
        tierClass: 'tier-freespin'
      };
    }

    const bet = getCurrentBet() || 1;
    const mult = amount / bet;

    if (mult >= 1000) {
      return {
        title: 'MAX WIN!',
        subtitle: 'KEMENANGAN MAKSIMAL PETIR ZEUS!',
        emblem: '⚡',
        tierClass: 'tier-max'
      };
    } else if (mult >= 500) {
      return {
        title: 'MASSIVE WIN!',
        subtitle: 'KEMENANGAN DAHSYAT OLYMPUS!',
        emblem: '💥',
        tierClass: 'tier-massive'
      };
    } else if (mult >= 250) {
      return {
        title: 'EPIC WIN!',
        subtitle: 'KEMENANGAN LEGENDA DEWA!',
        emblem: '🔥',
        tierClass: 'tier-epic'
      };
    } else if (mult >= 100) {
      return {
        title: 'SUPER WIN!',
        subtitle: 'KEMENANGAN LUAR BIASA!',
        emblem: '👑',
        tierClass: 'tier-super'
      };
    } else if (mult >= 50) {
      return {
        title: 'MEGA WIN!',
        subtitle: 'KEMENANGAN BESAR!',
        emblem: '💎',
        tierClass: 'tier-mega'
      };
    } else if (mult >= 20) {
      return {
        title: 'BIG WIN!',
        subtitle: 'KEMENANGAN BESAR!',
        emblem: '💰',
        tierClass: 'tier-big'
      };
    }
    return null;
  }

  // --- CELEBRATION CANVAS PARTICLES (GOLD COINS & SPARKS) ---
  const CelebrationFX = {
    canvas: null,
    ctx: null,
    particles: [],
    animId: null,

    init() {
      this.canvas = document.getElementById('celebration-coins-canvas');
      if (this.canvas) {
        this.ctx = this.canvas.getContext('2d');
      }
    },

    resize() {
      if (!this.canvas) return;
      this.canvas.width = window.innerWidth;
      this.canvas.height = window.innerHeight;
    },

    start() {
      this.init();
      if (!this.canvas || !this.ctx) return;
      this.resize();
      this.particles = [];
      const count = Math.min(50, Math.max(25, Math.floor(window.innerWidth / 20)));
      for (let i = 0; i < count; i++) {
        this.particles.push({
          x: Math.random() * this.canvas.width,
          y: -20 - Math.random() * (this.canvas.height * 0.7),
          radius: 9 + Math.random() * 11,
          speedY: 3.5 + Math.random() * 4.5,
          speedX: (Math.random() - 0.5) * 3,
          rotation: Math.random() * Math.PI * 2,
          rotSpeed: 0.05 + Math.random() * 0.08,
          color: Math.random() > 0.35 ? '#ffd700' : '#f59e0b',
          isSpark: Math.random() < 0.3
        });
      }

      const loop = () => {
        if (!state.celebrationActive) return;
        this.render();
        this.animId = requestAnimationFrame(loop);
      };
      this.animId = requestAnimationFrame(loop);
    },

    render() {
      if (!this.ctx || !this.canvas) return;
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

      for (let p of this.particles) {
        p.y += p.speedY;
        p.x += p.speedX;
        p.rotation += p.rotSpeed;

        if (p.y > this.canvas.height + 30) {
          p.y = -20;
          p.x = Math.random() * this.canvas.width;
        }

        this.ctx.save();
        this.ctx.translate(p.x, p.y);
        this.ctx.rotate(p.rotation);

        if (p.isSpark) {
          this.ctx.fillStyle = '#ffffff';
          this.ctx.shadowColor = '#00e5ff';
          this.ctx.shadowBlur = 8;
          this.ctx.beginPath();
          this.ctx.moveTo(0, -p.radius);
          this.ctx.lineTo(p.radius * 0.3, -p.radius * 0.3);
          this.ctx.lineTo(p.radius, 0);
          this.ctx.lineTo(p.radius * 0.3, p.radius * 0.3);
          this.ctx.lineTo(0, p.radius);
          this.ctx.lineTo(-p.radius * 0.3, p.radius * 0.3);
          this.ctx.lineTo(-p.radius, 0);
          this.ctx.lineTo(-p.radius * 0.3, -p.radius * 0.3);
          this.ctx.closePath();
          this.ctx.fill();
        } else {
          const yScale = Math.abs(Math.cos(p.rotation));
          this.ctx.scale(1, Math.max(0.2, yScale));

          this.ctx.beginPath();
          this.ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
          this.ctx.fillStyle = p.color;
          this.ctx.shadowColor = '#ffd700';
          this.ctx.shadowBlur = 6;
          this.ctx.fill();

          this.ctx.beginPath();
          this.ctx.arc(0, 0, p.radius * 0.72, 0, Math.PI * 2);
          this.ctx.strokeStyle = '#fffbeb';
          this.ctx.lineWidth = 1.2;
          this.ctx.stroke();

          this.ctx.fillStyle = '#ffffff';
          this.ctx.font = 'bold ' + Math.floor(p.radius * 0.8) + 'px sans-serif';
          this.ctx.textAlign = 'center';
          this.ctx.textBaseline = 'middle';
          this.ctx.fillText('⚡', 0, 0);
        }

        this.ctx.restore();
      }
    },

    stop() {
      if (this.animId) {
        cancelAnimationFrame(this.animId);
        this.animId = null;
      }
      if (this.ctx && this.canvas) {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      }
    }
  };

  window.addEventListener('resize', () => {
    if (state.celebrationActive) {
      CelebrationFX.resize();
    }
  });

  // --- CELEBRATION MODAL DISPLAY & PAUSE PROMISE ---
  let celebrationCountAnim = null;
  let celebrationAutoDismissTimer = null;

  function showCelebrationModal(amount, tierInfo) {
    return new Promise((resolve) => {
      state.celebrationActive = true;
      state.celebrationResolver = resolve;

      const overlay = el.celebrationOverlay;
      const titleEl = el.celebrationTitle;
      const subtitleEl = el.celebrationSubtitle;
      const amountEl = el.celebrationAmount;
      const emblemEl = el.celebrationEmblem;
      const cardBox = el.celebrationCardBox;

      if (!overlay || !amountEl) {
        state.celebrationActive = false;
        resolve();
        return;
      }

      // 1. Populate text & tier glow
      if (titleEl) {
        titleEl.textContent = tierInfo.title;
        titleEl.className = 'celebration-title ' + (tierInfo.tierClass || 'tier-big');
      }
      if (emblemEl) {
        emblemEl.textContent = tierInfo.emblem || '👑';
      }
      if (subtitleEl) {
        if (tierInfo.subtitle) {
          subtitleEl.textContent = tierInfo.subtitle;
          subtitleEl.style.display = 'block';
        } else {
          subtitleEl.style.display = 'none';
        }
      }

      amountEl.textContent = '+0';

      // Re-trigger entrance pop animation
      if (cardBox) {
        cardBox.style.animation = 'none';
        void cardBox.offsetWidth;
        cardBox.style.animation = 'zoomPopCelebration 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
      }

      overlay.style.display = 'flex';

      // 2. Start Canvas Coin Particles
      CelebrationFX.start();

      // 3. Audio & Haptics
      AudioFX.bigFanfare();
      triggerVibrate(120);

      // 4. Rolling Counter Animation (Smooth count-up with coin audio)
      const duration = 2400;
      const startTime = performance.now();
      let lastSoundTick = 0;

      function stepCount(now) {
        if (!state.celebrationActive) return;
        const elapsed = now - startTime;
        const progress = Math.min(1, elapsed / duration);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const currentVal = Math.floor(amount * easeOut);
        amountEl.textContent = '+' + formatNumber(currentVal);

        if (now - lastSoundTick > 75 && progress < 1) {
          AudioFX.coinTick();
          lastSoundTick = now;
        }

        if (progress < 1) {
          celebrationCountAnim = requestAnimationFrame(stepCount);
        } else {
          amountEl.textContent = '+' + formatNumber(amount);
          AudioFX.celebrationCheer();
          triggerVibrate(80);

          // Auto dismiss after 3 seconds of showing full amount if not clicked
          celebrationAutoDismissTimer = setTimeout(() => {
            finishCelebration();
          }, 3000);
        }
      }

      celebrationCountAnim = requestAnimationFrame(stepCount);
    });
  }

  // Tombol Skip di pojok kanan bawah popup
  function skipCelebration() {
    AudioFX.buttonClick();
    triggerVibrate(30);
    finishCelebration();
  }

  // Tombol Klaim Selesai
  function dismissCelebration() {
    AudioFX.buttonClick();
    triggerVibrate(30);
    finishCelebration();
  }

  function finishCelebration() {
    if (!state.celebrationActive) return;
    state.celebrationActive = false;

    if (celebrationCountAnim) {
      cancelAnimationFrame(celebrationCountAnim);
      celebrationCountAnim = null;
    }
    if (celebrationAutoDismissTimer) {
      clearTimeout(celebrationAutoDismissTimer);
      celebrationAutoDismissTimer = null;
    }

    CelebrationFX.stop();

    if (el.celebrationOverlay) {
      el.celebrationOverlay.style.display = 'none';
    }

    if (typeof state.celebrationResolver === 'function') {
      const resolve = state.celebrationResolver;
      state.celebrationResolver = null;
      resolve();
    }
  }

  // --- TOP MENU (SOUND, VIBRATION, LOBBY) ---
  function toggleTopMenu() {
    const dropdown = el.topMenuDropdown;
    if (!dropdown) return;
    const isShowing = dropdown.style.display === 'flex';
    dropdown.style.display = isShowing ? 'none' : 'flex';
    AudioFX.spinTick();
  }

  function toggleSound() {
    state.soundEnabled = !state.soundEnabled;
    const badge = document.getElementById('menu-sound-badge');
    const icon = document.getElementById('menu-sound-icon');
    if (badge) {
      badge.textContent = state.soundEnabled ? 'ON' : 'OFF';
      badge.className = 'item-toggle-badge' + (state.soundEnabled ? '' : ' is-off');
    }
    if (icon) {
      icon.textContent = state.soundEnabled ? '🔊' : '🔇';
    }
    if (state.soundEnabled) AudioFX.spinTick();
  }

  function toggleVibration() {
    state.vibrationEnabled = !state.vibrationEnabled;
    const badge = document.getElementById('menu-vibe-badge');
    const icon = document.getElementById('menu-vibe-icon');
    if (badge) {
      badge.textContent = state.vibrationEnabled ? 'ON' : 'OFF';
      badge.className = 'item-toggle-badge' + (state.vibrationEnabled ? '' : ' is-off');
    }
    if (icon) {
      icon.textContent = state.vibrationEnabled ? '📳' : '📴';
    }
    if (state.vibrationEnabled) triggerVibrate(50);
  }

  function exitGame() {
    if (el.topMenuDropdown) el.topMenuDropdown.style.display = 'none';
    if (Bridge.has() && typeof window.AndroidBridge.closeGame === 'function') {
      Bridge.call('closeGame');
    } else {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        alert('Kembali ke Lobby Kasino.');
      }
    }
  }

  function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.style.display = 'none';
  }

  // Close menus on outside click
  window.addEventListener('click', function (e) {
    const menuWrap = document.querySelector('.top-menu-wrapper');
    if (menuWrap && !menuWrap.contains(e.target) && el.topMenuDropdown) {
      el.topMenuDropdown.style.display = 'none';
    }
    const spinContainer = document.querySelector('.spin-button-container');
    if (spinContainer && !spinContainer.contains(e.target) && el.autoSpinPopup) {
      el.autoSpinPopup.style.display = 'none';
    }
  });

  // =========================================================================
  // OLIVERA CASINO SPECIFICATION: CALLBACKS & GLOBAL WINDOW EXPORTS
  // =========================================================================

  // [CB 01] UPDATE SALDO KOIN SECARA REALTIME
  window.setPlayerCoins = function (coins) {
    const c = Number(coins) || 0;
    state.coins = c;
    const chipDisp = document.getElementById('chip-disp');
    if (chipDisp) {
      chipDisp.textContent = '🪙 ' + c.toLocaleString('id-ID');
    }
    const playerChips = document.getElementById('player-chips');
    if (playerChips) {
      playerChips.textContent = formatNumber(c);
    }
    updateDisplays();
  };

  // [CB 02] UPDATE PROFIL PEMAIN SECARA REALTIME
  window.setPlayerProfile = function (profileJson) {
    try {
      const p = (typeof profileJson === 'string') ? JSON.parse(profileJson) : profileJson;
      if (!p) return;

      if (p.displayName) {
        state.playerName = p.displayName;
        const nameEl = document.getElementById('player-name');
        if (nameEl) nameEl.textContent = p.displayName;
      }

      if (p.vipString) {
        state.vipString = p.vipString;
        const vipEl = document.getElementById('player-vip');
        if (vipEl) vipEl.textContent = p.vipString;
      } else if (p.vipLevel !== undefined && p.vipLevel !== null) {
        state.vipString = 'VIP' + p.vipLevel;
        const vipEl = document.getElementById('player-vip');
        if (vipEl) vipEl.textContent = state.vipString;
      }

      if (p.playerLevel !== undefined && p.playerLevel !== null) {
        state.playerLevel = p.playerLevel;
        const lvlEl = document.getElementById('player-level');
        if (lvlEl) lvlEl.textContent = p.playerLevel;
      }

      const infoEl = document.getElementById('player-info');
      if (infoEl) {
        infoEl.textContent = (p.displayName || 'Player') + ' | ' + (p.vipString || 'VIP0') + ' | Lv ' + (p.playerLevel || 1);
      }

      if (p.chipBalance !== undefined && p.chipBalance !== null) {
        window.setPlayerCoins(p.chipBalance);
      }

      if (p.avatarUrl && p.avatarUrl.trim() !== '') {
        const avatarImg = document.getElementById('player-avatar-img');
        if (avatarImg) avatarImg.src = p.avatarUrl;
      }
    } catch (e) {
      console.warn('[OliveraCasino] Error parsing player profile:', e);
    }
  };

  // [CB 03] UPDATE PROGRESSIVE JACKPOT SECARA REALTIME
  window.onJackpotUpdate = function (jackpotAmount) {
    const jp = Number(jackpotAmount) || 0;
    state.jackpot = jp;
    const jpDisp = document.getElementById('jackpot-disp');
    if (jpDisp) {
      jpDisp.textContent = 'JP ' + jp.toLocaleString('id-ID');
    }
    const jpVal = document.getElementById('jackpot-val');
    if (jpVal) {
      jpVal.textContent = formatNumber(jp);
    }
    const jpAlt = document.getElementById('jackpot-display');
    if (jpAlt) {
      jpAlt.textContent = formatNumber(jp);
    }
  };

  // [ID 01 / ID 02] Template spinSlot convenience method
  window.spinSlot = function (bet) {
    if (typeof bet === 'number' && bet > 0) {
      const idx = BET_LEVELS.indexOf(bet);
      if (idx !== -1) {
        state.betIndex = idx;
      }
    }
    handleSpinAction();
  };

  window.setBet = function (amount) {
    const idx = BET_LEVELS.indexOf(amount);
    if (idx !== -1) {
      state.betIndex = idx;
      updateDisplays();
    }
  };

  window.updateDisplays = updateDisplays;
  window.adjustBet = adjustBet;
  window.startSpin = handleSpinAction;
  window.handleSpinAction = handleSpinAction;
  window.runSpinAnimation = runSpinAnimation;
  window.triggerZeusLightning = triggerZeusLightning;
  window.manualLightningStrike = () => triggerZeusLightning(1000);
  window.evaluateClusters = evaluateClusters;
  window.showCelebration = showCelebrationModal;
  window.dismissCelebration = dismissCelebration;
  window.skipCelebration = skipCelebration;
  window.startFreeSpinsFromPopup = startFreeSpinsFromPopup;
  window.showFreeSpinsIntroModal = showFreeSpinsIntroModal;
  window.testFreespin10Popup = async function () {
    closeModal('paytable-modal');
    closeModal('chat-modal');
    await showFreeSpinsIntroModal(10);
  };
  window.testCelebration = async function (tierType) {
    closeModal('paytable-modal');
    closeModal('chat-modal');
    const bet = getCurrentBet() || 30000;
    let amt = bet * 25;
    let isFs = false;
    let rounds = 10;

    switch (tierType) {
      case 'big':
        amt = bet * 25;
        break;
      case 'mega':
        amt = bet * 60;
        break;
      case 'super':
        amt = bet * 125;
        break;
      case 'epic':
        amt = bet * 300;
        break;
      case 'massive':
        amt = bet * 600;
        break;
      case 'max':
        amt = bet * 1200;
        break;
      case 'freespin':
        amt = bet * 850;
        isFs = true;
        rounds = 10;
        break;
      default:
        amt = bet * 25;
    }

    const tier = determineCelebrationTier(amt, isFs, rounds);
    await showCelebrationModal(amt, tier);
  };
  window.exitGame = exitGame;
  window.closeModal = closeModal;
  window.buyFreeSpinsDirect = buyFreeSpinsDirect;
  window.cycleSpeed = cycleSpeed;
  window.selectAutoSpin = selectAutoSpin;
  window.toggleTopMenu = toggleTopMenu;
  window.toggleSound = toggleSound;
  window.toggleVibration = toggleVibration;

  window.openPaytable = function () {
    if (el.paytableModal) el.paytableModal.style.display = 'flex';
  };
  window.openChatInfo = function () {
    if (el.chatModal) el.chatModal.style.display = 'flex';
  };
  window.openProfileInfo = function () {
    alert('Player: ' + state.playerName + '\nLevel: ' + state.playerLevel + ' (' + (state.vipString || 'VIP3') + ')\nSaldo: ' + formatNumber(state.coins) + ' Chip\nID: ' + state.playerId);
  };
  window.openBetModal = openBetModal;
  window.addDemoCoins = addDemoCoins;

  // --- KEYBOARD SHORTCUTS ---
  window.addEventListener('keydown', function (e) {
    if (e.code === 'Space' || e.key === ' ' || e.code === 'Enter') {
      e.preventDefault();
      handleSpinAction();
    }
  });

  // --- INIT & ANDROID BRIDGE SYNC ON LOAD (Olivera Casino Standard) ---
  window.addEventListener('DOMContentLoaded', function () {
    bindSpinLongPress();

    if (Bridge.has()) {
      try {
        // [ID 04] Get initial coin balance
        if (typeof window.AndroidBridge.getCoins === 'function') {
          const c = window.AndroidBridge.getCoins();
          if (c !== undefined && c !== null && !isNaN(Number(c)) && Number(c) >= 0) {
            window.setPlayerCoins(Number(c));
          }
        }

        // [ID 05] Get player profile JSON
        if (typeof window.AndroidBridge.getPlayerProfile === 'function') {
          const profile = window.AndroidBridge.getPlayerProfile();
          if (profile) {
            window.setPlayerProfile(profile);
          }
        } else {
          // Fallbacks for individual methods
          if (typeof window.AndroidBridge.getPlayerLevel === 'function') {
            const lvl = window.AndroidBridge.getPlayerLevel();
            if (typeof lvl === 'number') {
              state.playerLevel = lvl;
              const lvlEl = document.getElementById('player-level');
              if (lvlEl) lvlEl.textContent = lvl;
            }
          }
          if (typeof window.AndroidBridge.getVipString === 'function') {
            const vip = window.AndroidBridge.getVipString();
            if (vip) {
              state.vipString = vip;
              const vipEl = document.getElementById('player-vip');
              if (vipEl) vipEl.textContent = vip;
            }
          }
        }

        // [ID 09] Get initial jackpot
        if (typeof window.AndroidBridge.getJackpot === 'function') {
          const jp = window.AndroidBridge.getJackpot('gates_of_olympus');
          if (jp !== undefined && jp !== null && !isNaN(Number(jp)) && Number(jp) > 0) {
            window.onJackpotUpdate(Number(jp));
          }
        }

        if (typeof window.AndroidBridge.getBetAmount === 'function') {
          const b = window.AndroidBridge.getBetAmount();
          if (typeof b === 'number' && b > 0) {
            const bIdx = BET_LEVELS.indexOf(b);
            if (bIdx !== -1) state.betIndex = bIdx;
          }
        }
      } catch (e) {
        console.warn('[OliveraCasino] Bridge init warning:', e);
      }
    }

    initBoard();
    updateDisplays();

    // Signal ready to Android container
    Bridge.call('onGameReady');
  });

})();
