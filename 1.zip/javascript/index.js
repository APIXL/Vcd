/**
 * Gates of Olympus - Exact Landscape Edition
 * Pure Vanilla JavaScript ES6
 * Zero External Dependencies
 * Full AndroidBridge & Olivera Casino Integration
 */

(function () {
  'use strict';

  // --- SYMBOL CATALOG ---
  const SYMBOLS = [
    { id: 'scatter', name: 'Scatter Zeus', img: '/assets/img/scatter.svg', isScatter: true, basePayout: 100 },
    { id: 'crown', name: 'Mahkota Emas', img: '/assets/img/crown.svg', basePayout: 50 },
    { id: 'hourglass', name: 'Jam Pasir', img: '/assets/img/hourglass.svg', basePayout: 25 },
    { id: 'ring', name: 'Cincin Ruby', img: '/assets/img/ring.svg', basePayout: 15 },
    { id: 'chalice', name: 'Piala Olympus', img: '/assets/img/chalice.svg', basePayout: 12 },
    { id: 'gem_red', name: 'Batu Merah', img: '/assets/img/gem-red.svg', basePayout: 10 },
    { id: 'gem_purple', name: 'Batu Ungu', img: '/assets/img/gem-purple.svg', basePayout: 8 },
    { id: 'gem_yellow', name: 'Batu Kuning', img: '/assets/img/gem-yellow.svg', basePayout: 5 },
    { id: 'gem_green', name: 'Batu Hijau', img: '/assets/img/gem-green.svg', basePayout: 4 },
    { id: 'gem_blue', name: 'Batu Biru', img: '/assets/img/gem-blue.svg', basePayout: 2 }
  ];

  const MULTIPLIER_VALUES = [2, 3, 5, 10, 20, 30, 50, 100, 250, 500];

  const BET_LEVELS = [
    200, 400, 800, 1200, 2000, 5000, 10000, 20000, 30000, 50000, 100000, 250000, 500000, 1000000
  ];

  // --- GAME STATE ---
  const state = {
    playerId: 'PLAYER_GUEST',
    playerName: 'Pemain Olympus',
    playerLevel: 7,
    vipString: 'VIP3',
    vipLevel: 3,
    coins: 419306,
    jackpot: 52849200000,
    betIndex: 8, // 30,000 matches BET

    isSpinning: false,
    stopRequested: false,

    // Speed setting: 1X, 2X, 3X, 4X
    speedMultiplier: 1,

    // Sound & Vibration toggles
    soundEnabled: true,
    vibrationEnabled: true,

    // Auto Spin state
    autoSpinsRemaining: 0,

    // Free Spins State
    inFreeSpins: false,
    freeSpinsTotalAllocated: 0,
    freeSpinsRemaining: 0,
    freeSpinsTotalWin: 0,
    accumulatedGlobalMultiplier: 1,

    // Celebration Animated Popup State (Pauses spin until popup finishes or is skipped)
    celebrationActive: false,
    celebrationResolver: null,

    // Round Multiplier State (Top-Left Medallion starts at 1x, resets ONLY when spin starts)
    tumbleMultiplierSum: 1,
    currentTumbleWin: 0,
    lastTotalWin: 0, // Persisted across tumble/spin/freespin until next spin starts
    currentRoundMultipliers: [],
    roundBreakdown: [],
    
    // 6 columns x 5 rows grid: indexed [col][row]
    board: []
  };

  // --- UTILS ---
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function formatNumber(num) {
    return Math.floor(num).toLocaleString('id-ID');
  }

  function formatShort(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return Math.floor(num / 1000) + 'K';
    return num.toString();
  }

  function getCurrentBet() {
    return BET_LEVELS[state.betIndex];
  }

  function triggerVibrate(ms = 40) {
    if (!state.vibrationEnabled) return;
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
        navigator.vibrate(ms);
      }
    } catch (_) {}
  }

  // --- PROCEDURAL WEB AUDIO SYNTHESIZER WITH ANDROID SOUNDPOOL BRIDGE ---
  const AudioFX = {
    ctx: null,
    init() {
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
          this.ctx = new AudioCtx();
        }
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    },
    playTone(freq, type = 'sine', duration = 0.1, gainVal = 0.15) {
      if (!state.soundEnabled) return;
      try {
        this.init();
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {}
    },
    playNativeOrWeb(sfxId, webFallbackFn) {
      if (state.soundEnabled && Bridge.has() && typeof window.AndroidBridge.playSfx === 'function') {
        try {
          window.AndroidBridge.playSfx(sfxId);
        } catch (_) {}
      }
      if (webFallbackFn) {
        webFallbackFn();
      }
    },
    spinTick() {
      this.playNativeOrWeb('spin', () => {
        this.playTone(320 + Math.random() * 80, 'triangle', 0.04, 0.08);
      });
    },
    buttonClick() {
      this.playNativeOrWeb('click', () => {
        this.playTone(440, 'triangle', 0.04, 0.1);
      });
    },
    tumbleExplode() {
      this.playNativeOrWeb('click', () => {
        this.playTone(200, 'sawtooth', 0.12, 0.18);
      });
    },
    winChime() {
      this.playNativeOrWeb('win', () => {
        this.playTone(523, 'triangle', 0.12, 0.15);
        setTimeout(() => this.playTone(659, 'triangle', 0.12, 0.18), 70);
        setTimeout(() => this.playTone(784, 'triangle', 0.18, 0.2), 140);
      });
    },
    scatterDing() {
      this.playNativeOrWeb('scatter', () => {
        this.playTone(880, 'sine', 0.25, 0.3);
        setTimeout(() => this.playTone(1174, 'sine', 0.35, 0.3), 100);
      });
    },
    thunderStrike() {
      this.playNativeOrWeb('coin', () => {
        try {
          this.init();
          if (!this.ctx) return;
          const bufferSize = this.ctx.sampleRate * 0.35;
          const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
          const data = buffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }
          const noise = this.ctx.createBufferSource();
          noise.buffer = buffer;
          const filter = this.ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(400, this.ctx.currentTime);
          filter.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.35);
          const gain = this.ctx.createGain();
          gain.gain.setValueAtTime(0.35, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);
          noise.connect(filter);
          filter.connect(gain);
          gain.connect(this.ctx.destination);
          noise.start();
        } catch (e) {}
      });
    },
    bigFanfare() {
      this.playNativeOrWeb('jackpot', () => {
        const notes = [523, 659, 784, 1046, 1318];
        notes.forEach((f, idx) => {
          setTimeout(() => this.playTone(f, 'sawtooth', 0.18, 0.15), idx * 90);
        });
      });
    },
    coinTick() {
      if (!state.soundEnabled) return;
      this.playTone(850 + Math.random() * 250, 'triangle', 0.04, 0.08);
    },
    celebrationCheer() {
      this.playNativeOrWeb('jackpot', () => {
        const chords = [523.25, 659.25, 783.99, 1046.5];
        chords.forEach((f, i) => {
          setTimeout(() => this.playTone(f, 'sawtooth', 0.28, 0.22), i * 85);
        });
      });
    }
  };

  // --- SAFE ANDROID BRIDGE INVOCATION HELPER ---
  const Bridge = {
    has() {
      return typeof window.AndroidBridge !== 'undefined' && window.AndroidBridge !== null;
    },
    call(methodName, ...args) {
      if (this.has() && typeof window.AndroidBridge[methodName] === 'function') {
        try {
          return window.AndroidBridge[methodName](...args);
        } catch (e) {
          console.warn('[AndroidBridge Error in ' + methodName + ']:', e);
          if (typeof window.AndroidBridge.onError === 'function') {
            try {
              window.AndroidBridge.onError(e.message || String(e));
            } catch (_) {}
          }
        }
      }
      return undefined;
    }
  };

  // --- DOM ELEMENTS REFERENCE ---
  const el = {
    get grid() { return document.getElementById('grid') || document.getElementById('matrix-grid'); },
    get playerChips() { return document.getElementById('player-chips'); },
    get betDisplay() { return document.getElementById('bet-display') || document.getElementById('bet-display-val'); },
    get winDisplay() { return document.getElementById('win-display') || document.getElementById('win-display-val'); },
    get jackpotDisplay() { return document.getElementById('jackpot-display'); },
    get tumbleWinVal() { return document.getElementById('tumble-win-val'); },
    get totalMultNum() { return document.getElementById('total-multiplier-number'); },
    get sisaFreeSpinBox() { return document.getElementById('sisa-freespin-box'); },
    get sisaFreeSpinVal() { return document.getElementById('sisa-freespin-val'); },
    get fsBadgeBtn() { return document.getElementById('fs-badge-btn'); },
    get fsFractionVal() { return document.getElementById('fs-fraction-val'); },
    get speedToggleBtn() { return document.getElementById('round-multiplier-pill'); },
    get speedValText() { return document.getElementById('round-multiplier-val'); },
    get spinBtn() { return document.getElementById('spin-btn') || document.getElementById('btn-spin-action'); },
    get autoSpinPopup() { return document.getElementById('auto-spin-popup'); },
    get tumbleBreakdownCard() { return document.getElementById('tumble-breakdown-card'); },
    get zeusFigureBox() { return document.getElementById('zeus-figure-box'); },
    get lightningFlash() { return document.getElementById('lightning-flash') || document.getElementById('screen-flash'); },
    get lightningSvgGroup() { return document.getElementById('lightning-paths-group'); },
    get gameViewport() { return document.getElementById('game-viewport'); },

    // Modals, Celebration Popup, & Menu
    get topMenuDropdown() { return document.getElementById('top-menu-dropdown'); },
    get paytableModal() { return document.getElementById('paytable-modal'); },
    get betModal() { return document.getElementById('bet-modal'); },
    get chatModal() { return document.getElementById('chat-modal'); },
    get celebrationOverlay() { return document.getElementById('celebration-overlay') || document.getElementById('celebration-modal'); },
    get celebrationTitle() { return document.getElementById('celebration-title'); },
    get celebrationSubtitle() { return document.getElementById('celebration-subtitle'); },
    get celebrationEmblem() { return document.getElementById('celebration-emblem'); },
    get celebrationCardBox() { return document.getElementById('celebration-card-box'); },
    get celebrationAmount() { return document.getElementById('celebration-amount') || document.getElementById('celebration-val'); },
    get celebrationCoinsCanvas() { return document.getElementById('celebration-coins-canvas'); },
    get btnSkipCelebration() { return document.getElementById('btn-skip-celebration'); }
  };

  // --- BOARD INITIALIZATION ---
  function initBoard() {
    const gridEl = el.grid;
    if (!gridEl) return;
    gridEl.innerHTML = '';
    state.board = [];

    // 6 columns x 5 rows = 30 cells
    for (let col = 0; col < 6; col++) {
      state.board[col] = [];
      for (let row = 0; row < 5; row++) {
        const cell = document.createElement('div');
        cell.className = 'slot-cell';
        cell.dataset.col = col;
        cell.dataset.row = row;

        const sym = getRandomSymbol();
        const img = document.createElement('img');
        img.className = 'cell-symbol-img';
        img.src = sym.img;
        img.alt = sym.name;

        cell.appendChild(img);
        gridEl.appendChild(cell);

        state.board[col][row] = {
          el: cell,
          img: img,
          sym: sym,
          isOrb: false,
          mult: 0
        };
      }
    }
  }

  function hasMultiplierOnBoard() {
    if (!state.board || state.board.length === 0) return false;
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col] && state.board[col][row];
        if (item && item.isOrb) return true;
      }
    }
    return false;
  }

  function getRandomSymbol() {
    // Keseimbangan probabilitas
    if (hasMultiplierOnBoard()) {
      const counts = {};
      for (let col = 0; col < 6; col++) {
        for (let row = 0; row < 5; row++) {
          const item = state.board[col] && state.board[col][row];
          if (item && item.sym && !item.isOrb) {
            counts[item.sym.id] = (counts[item.sym.id] || 0) + 1;
          }
        }
      }
      const candidates = SYMBOLS.slice(1);
      candidates.sort((a, b) => (counts[a.id] || 0) - (counts[b.id] || 0));
      const pool = candidates.slice(0, 4);
      return pool[Math.floor(Math.random() * pool.length)];
    }

    const r = Math.random();
    if (r < 0.035) return SYMBOLS[0]; // Scatter
    if (r < 0.10) return SYMBOLS[1];  // Crown
    if (r < 0.20) return SYMBOLS[2];  // Hourglass
    if (r < 0.32) return SYMBOLS[3];  // Ring
    if (r < 0.44) return SYMBOLS[4];  // Chalice
    if (r < 0.56) return SYMBOLS[5];  // Gem Red
    if (r < 0.68) return SYMBOLS[6];  // Gem Purple
    if (r < 0.79) return SYMBOLS[7];  // Gem Yellow
    if (r < 0.89) return SYMBOLS[8];  // Gem Green
    return SYMBOLS[9];                // Gem Blue
  }

  // --- UI UPDATERS (updateDisplays) ---
  function updateDisplays() {
    if (el.playerChips) el.playerChips.textContent = formatNumber(state.coins);
    if (el.betDisplay) el.betDisplay.textContent = formatNumber(getCurrentBet());
    if (el.jackpotDisplay) el.jackpotDisplay.textContent = formatNumber(state.jackpot);
    if (el.tumbleWinVal) el.tumbleWinVal.textContent = formatNumber(state.currentTumbleWin);

    // 1. Total Multiplier Medallion in top-left:
    // Does NOT reset to 1x when tumble finishes. Resets only when a new spin begins!
    const displayMult = state.inFreeSpins ? state.accumulatedGlobalMultiplier : state.tumbleMultiplierSum;
    if (el.totalMultNum) el.totalMultNum.textContent = displayMult + 'x';

    // 2. Win display in center bottom:
    // Retains lastTotalWin across tumble/spin/freespin until next spin starts.
    if (el.winDisplay) {
      el.winDisplay.textContent = formatNumber(state.lastTotalWin);
    }

    // 3. Free Spin Counters and Conditional Visibility:
    if (state.inFreeSpins) {
      if (el.sisaFreeSpinBox) el.sisaFreeSpinBox.style.display = 'block';
      if (el.fsBadgeBtn) el.fsBadgeBtn.style.display = 'flex';
      if (el.sisaFreeSpinVal) el.sisaFreeSpinVal.textContent = state.freeSpinsRemaining;
      if (el.fsFractionVal) el.fsFractionVal.textContent = (state.freeSpinsTotalAllocated - state.freeSpinsRemaining) + '/' + state.freeSpinsTotalAllocated;
    } else {
      if (el.sisaFreeSpinBox) el.sisaFreeSpinBox.style.display = 'none';
      if (el.fsBadgeBtn) el.fsBadgeBtn.style.display = 'none';
    }

    // 4. Speed toggle button next to spin (1X -> 2X -> 3X -> 4X)
    if (el.speedValText) el.speedValText.textContent = state.speedMultiplier + 'X';
    if (el.speedToggleBtn) {
      if (state.speedMultiplier > 1) {
        el.speedToggleBtn.classList.add('speed-boosted');
      } else {
        el.speedToggleBtn.classList.remove('speed-boosted');
      }
    }

    // 5. Spin action button state (SPIN / STOP or Auto remaining)
    if (el.spinBtn) {
      if (state.isSpinning) {
        if (state.autoSpinsRemaining > 0) {
          const autoTxt = state.autoSpinsRemaining > 100000 ? '∞' : state.autoSpinsRemaining;
          el.spinBtn.textContent = 'STOP (' + autoTxt + ')';
        } else {
          el.spinBtn.textContent = 'STOP';
        }
        el.spinBtn.classList.add('is-stop');
      } else {
        if (state.autoSpinsRemaining > 0) {
          const autoTxt = state.autoSpinsRemaining > 100000 ? '∞' : state.autoSpinsRemaining;
          el.spinBtn.textContent = 'AUTO (' + autoTxt + ')';
        } else {
          el.spinBtn.textContent = 'SPIN';
        }
        el.spinBtn.classList.remove('is-stop');
      }
    }
  }

  function renderBreakdown() {
    const card = el.tumbleBreakdownCard;
    if (!card) return;
    if (state.roundBreakdown.length === 0) {
      card.innerHTML = `
        <div class="breakdown-row" style="color: #94a3b8; font-size: 8px; justify-content: center;">
          MENUNGGU TUMBLE...
        </div>`;
      return;
    }
    card.innerHTML = '';
    const recent = state.roundBreakdown.slice(-3);
    recent.forEach(item => {
      const row = document.createElement('div');
      row.className = 'breakdown-row';
      row.innerHTML = `
        <span class="breakdown-item-info">
          <span class="breakdown-count">${item.count}</span>
          <img src="${item.sym.img}" class="breakdown-icon" alt="${item.sym.name}" />
        </span>
        <span class="breakdown-payout">${formatShort(item.payout)}</span>
      `;
      card.appendChild(row);
    });
  }

  // --- SPEED TOGGLE (1X -> 2X -> 3X -> 4X) ---
  function cycleSpeed() {
    AudioFX.spinTick();
    triggerVibrate(30);
    state.speedMultiplier = (state.speedMultiplier % 4) + 1;
    updateDisplays();
  }

  // --- BET ADJUSTER ---
  function adjustBet(dir) {
    if (state.isSpinning) return;
    AudioFX.spinTick();
    triggerVibrate(25);
    state.betIndex += dir;
    if (state.betIndex < 0) state.betIndex = 0;
    if (state.betIndex >= BET_LEVELS.length) state.betIndex = BET_LEVELS.length - 1;
    updateDisplays();
  }

  function openBetModal() {
    if (state.isSpinning) return;
    const grid = document.getElementById('bet-options-grid');
    if (grid) {
      grid.innerHTML = '';
      BET_LEVELS.forEach((bet, idx) => {
        const btn = document.createElement('button');
        btn.className = 'bet-tile-btn' + (idx === state.betIndex ? ' selected' : '');
        btn.textContent = formatNumber(bet);
        btn.onclick = () => {
          state.betIndex = idx;
          updateDisplays();
          closeModal('bet-modal');
        };
        grid.appendChild(btn);
      });
    }
    if (el.betModal) el.betModal.style.display = 'flex';
  }

  function addDemoCoins() {
    AudioFX.winChime();
    triggerVibrate(40);
    state.coins += 5000000;
    Bridge.call('updateCoins', 5000000);
    updateDisplays();
  }

  // =========================================================================
  // ANDROID BRIDGE POPUPS: OPEN PROFILE & OPEN STORE
  // (ID_LIST.txt: [ID 11], [ID 12], [ID 13], [CB 04])
  // =========================================================================
  function openProfileDialog() {
    AudioFX.buttonClick();
    triggerVibrate(30);

    // Call AndroidBridge per ID_LIST.txt specification
    if (Bridge.has()) {
      if (typeof window.AndroidBridge.openProfile === 'function') {
        window.AndroidBridge.openProfile();
        return;
      }
      if (typeof window.AndroidBridge.openPopup === 'function') {
        window.AndroidBridge.openPopup('profile');
        return;
      }
      if (typeof window.AndroidBridge.openFragment === 'function') {
        window.AndroidBridge.openFragment('profile');
        return;
      }
    }

    // Standalone / browser testing fallback
    alert('👤 [PROFIL PEMAIN]\nNama: ' + state.playerName + '\nLevel: ' + state.playerLevel + ' (' + (state.vipString || 'VIP3') + ')\nSaldo: ' + formatNumber(state.coins) + ' Chip\nID: ' + state.playerId);
  }

  function openStoreDialog() {
    AudioFX.buttonClick();
    triggerVibrate(30);

    // Call AndroidBridge per ID_LIST.txt specification
    if (Bridge.has()) {
      if (typeof window.AndroidBridge.openStore === 'function') {
        window.AndroidBridge.openStore();
        return;
      }
      if (typeof window.AndroidBridge.openToko === 'function') {
        window.AndroidBridge.openToko();
        return;
      }
      if (typeof window.AndroidBridge.openPopup === 'function') {
        window.AndroidBridge.openPopup('store');
        return;
      }
      if (typeof window.AndroidBridge.openFragment === 'function') {
        window.AndroidBridge.openFragment('store');
        return;
      }
    }

    // Standalone / browser testing fallback
    addDemoCoins();
  }

  // --- AUTO SPIN LONG PRESS & POPUP ---
  let spinLongPressTimer = null;
  let isLongPressTriggered = false;

  function bindSpinLongPress() {
    const btn = el.spinBtn;
    if (!btn) return;

    const onPointerDown = () => {
      if (state.isSpinning) return;
      isLongPressTriggered = false;
      spinLongPressTimer = setTimeout(() => {
        isLongPressTriggered = true;
        toggleAutoSpinPopup(true);
      }, 450);
    };

    const onPointerUp = () => {
      if (spinLongPressTimer) {
        clearTimeout(spinLongPressTimer);
        spinLongPressTimer = null;
      }
    };

    btn.addEventListener('mousedown', onPointerDown);
    btn.addEventListener('touchstart', onPointerDown, { passive: true });
    btn.addEventListener('mouseup', onPointerUp);
    btn.addEventListener('mouseleave', onPointerUp);
    btn.addEventListener('touchend', onPointerUp);
    btn.addEventListener('touchcancel', onPointerUp);
  }

  function toggleAutoSpinPopup(show = null) {
    const popup = el.autoSpinPopup;
    if (!popup) return;
    const shouldShow = (show !== null) ? show : (popup.style.display === 'none');
    popup.style.display = shouldShow ? 'flex' : 'none';
    if (shouldShow) {
      AudioFX.spinTick();
      triggerVibrate(40);
    }
  }

  function selectAutoSpin(count) {
    toggleAutoSpinPopup(false);
    AudioFX.spinTick();
    triggerVibrate(40);
    state.autoSpinsRemaining = count;
    executeSpin();
  }

  // --- MAIN SPIN ACTION (SPIN / STOP) ---
  function handleSpinAction() {
    AudioFX.init();
    // If celebration popup is showing, clicking spin skips and dismisses it immediately
    if (state.celebrationActive) {
      skipCelebration();
      return;
    }
    if (isLongPressTriggered) {
      isLongPressTriggered = false;
      return;
    }
    // If auto-spin is running, clicking cancels it
    if (state.autoSpinsRemaining > 0) {
      state.autoSpinsRemaining = 0;
      state.stopRequested = true;
      updateDisplays();
      return;
    }
    // If reels are spinning, clicking requests instant stop
    if (state.isSpinning) {
      state.stopRequested = true;
      return;
    }
    executeSpin();
  }

  async function executeSpin(isBonusSpin = false) {
    if (state.isSpinning || state.celebrationActive) return;

    const bet = getCurrentBet();
    if (!isBonusSpin && !state.inFreeSpins) {
      if (state.coins < bet) {
        state.autoSpinsRemaining = 0;
        alert('Chip Anda tidak cukup untuk memasang taruhan!');
        updateDisplays();
        return;
      }
      state.coins -= bet;
      state.jackpot += Math.floor(bet * 0.03);

      // AndroidBridge: onSpinStart & onBet
      Bridge.call('onSpinStart');
      Bridge.call('onBet', bet);
      Bridge.call('updateCoins', -bet);
    }

    state.isSpinning = true;
    state.stopRequested = false;
    state.currentTumbleWin = 0;
    state.currentRoundMultipliers = [];
    state.roundBreakdown = [];
    
    // ATURAN 1 & 2:
    // Text multiplier di kiri atas reset ke 1x HANYA saat memulai spin!
    // Total win di tengah bawah reset ke 0 HANYA ketika spin baru dimulai!
    if (!state.inFreeSpins) {
      state.tumbleMultiplierSum = 1;
      state.lastTotalWin = 0;
      if (el.winDisplay) el.winDisplay.textContent = '0';
    }

    renderBreakdown();
    updateDisplays();

    // 1. Reel spinning roll (multiplier ikut drop bersama gem dari atas dan tersambar petir Zeus!)
    await runSpinAnimation();

    // 2. Tumble Cascade Loop (Evaluate 8+ clusters, explode, drop, repeat)
    let hasWins = false;
    let anyWinInRound = false;
    do {
      hasWins = await evaluateClusters();
      if (hasWins) {
        anyWinInRound = true;
      }
      if (state.stopRequested) break;
    } while (hasWins);

    // 4. Multiply Tumble Win by Multiplier Orbs gathered during tumble!
    if (anyWinInRound && state.currentRoundMultipliers.length > 0) {
      AudioFX.thunderStrike();
      if (state.inFreeSpins) {
        state.accumulatedGlobalMultiplier += (state.tumbleMultiplierSum > 1 ? state.tumbleMultiplierSum : 1);
        updateDisplays();
      }
      const multToApply = state.inFreeSpins ? state.accumulatedGlobalMultiplier : state.tumbleMultiplierSum;
      const totalWinCalculated = state.currentTumbleWin * multToApply;
      state.currentTumbleWin = totalWinCalculated;
      if (el.tumbleWinVal) el.tumbleWinVal.textContent = formatNumber(state.currentTumbleWin);
    }

    // 5. Finalize Round Payout & Bridge callbacks
    if (state.currentTumbleWin > 0) {
      const MAX_WIN_CAP = bet * 5000;
      let hitMaxWin = false;

      // Di dalam mode Free Spin, periksa batas MAX WIN (5.000x taruhan)
      if (state.inFreeSpins) {
        if ((state.freeSpinsTotalWin + state.currentTumbleWin) >= MAX_WIN_CAP) {
          hitMaxWin = true;
          state.currentTumbleWin = Math.max(0, MAX_WIN_CAP - state.freeSpinsTotalWin);
          state.freeSpinsTotalWin = MAX_WIN_CAP;
          state.coins += state.currentTumbleWin;
        } else {
          state.coins += state.currentTumbleWin;
          state.freeSpinsTotalWin += state.currentTumbleWin;
        }
        state.lastTotalWin = state.freeSpinsTotalWin;
      } else {
        state.coins += state.currentTumbleWin;
        state.lastTotalWin = state.currentTumbleWin;
      }

      // Pastikan total win di tengah bawah menampilkan nilai kemenangan terakhir
      if (el.winDisplay) {
        el.winDisplay.textContent = formatNumber(state.lastTotalWin);
      }

      // AndroidBridge: onWin & updateCoins
      Bridge.call('onWin', state.currentTumbleWin);
      Bridge.call('updateCoins', state.currentTumbleWin);

      // JIKA MENDAPATKAN MAXWIN DIDALAM MODE FREESPIN
      if (hitMaxWin) {
        state.freeSpinsRemaining = 0;
        state.inFreeSpins = false;
        state.isSpinning = false;
        state.stopRequested = false;
        updateDisplays();

        const maxWinTier = {
          title: 'MAX WIN!',
          subtitle: 'KEMENANGAN MAKSIMAL 5.000X TERCAPAI! SISA FREE SPIN DIHENTIKAN',
          emblem: '⚡👑⚡',
          tierClass: 'tier-max'
        };
        await showCelebrationModal(state.freeSpinsTotalWin, maxWinTier);
        // Total win tetap bertahan di win-display setelah freespin selesai!
        state.freeSpinsTotalWin = 0;
        if (el.winDisplay) el.winDisplay.textContent = formatNumber(state.lastTotalWin);
        updateDisplays();
        return;
      }

      // Check celebration tiers: Big Win, Mega Win, Super Win, Epic Win, Massive Win, Max Win
      const celebrationTier = determineCelebrationTier(state.currentTumbleWin, false);
      if (celebrationTier) {
        await showCelebrationModal(state.currentTumbleWin, celebrationTier);
      } else {
        AudioFX.winChime();
      }
    } else {
      // AndroidBridge: onLose if no win
      Bridge.call('onLose', bet);
    }

    // AndroidBridge: onSpinEnd
    Bridge.call('onSpinEnd');

    // 6. Check for Free Spins Trigger (4+ Zeus Scatters)
    await checkScatterBonus();

    // 7. Finish Spin
    state.isSpinning = false;
    state.stopRequested = false;

    // PENTING: text multiplier di kiri atas TIDAK reset ke 1x saat tumble selesai!
    // Total win di tengah bawah JUGA TIDAK hilang saat selesai tumble / spin!
    // Nilai tersebut tetap bertahan dan hanya direset ketika putaran baru dimulai.
    updateDisplays();

    // If currently in Free Spins, continue to next spin!
    if (state.inFreeSpins) {
      state.freeSpinsRemaining--;
      updateDisplays();

      if (state.freeSpinsRemaining > 0) {
        const nextDelay = Math.max(150, Math.floor(650 / state.speedMultiplier));
        setTimeout(() => executeSpin(true), nextDelay);
      } else {
        state.inFreeSpins = false;
        updateDisplays();

        // Selesai Free Spin Popup
        const fsTier = determineCelebrationTier(state.freeSpinsTotalWin, true, state.freeSpinsTotalAllocated || 10);
        const finalFsWin = state.freeSpinsTotalWin;
        state.lastTotalWin = finalFsWin; // Tahan nilai kemenangan akhir di display tengah bawah!

        await showCelebrationModal(finalFsWin, fsTier);
        state.freeSpinsTotalWin = 0;
        // Total win tetap ditampilkan di tengah bawah, TIDAK hilang saat selesai freespin!
        if (el.winDisplay) el.winDisplay.textContent = formatNumber(state.lastTotalWin);
        updateDisplays();
      }
      return;
    }

    // If Auto Spin is active, proceed to next spin
    if (state.autoSpinsRemaining > 0) {
      if (state.autoSpinsRemaining < 900000) {
        state.autoSpinsRemaining--;
      }
      if (state.autoSpinsRemaining > 0 && !state.stopRequested) {
        const autoDelay = Math.max(120, Math.floor(450 / state.speedMultiplier));
        setTimeout(() => executeSpin(), autoDelay);
      } else {
        state.autoSpinsRemaining = 0;
        updateDisplays();
      }
    }
  }

  // --- MULTIPLIER ORB HELPERS ---
  function getBadgeColorClass(mult) {
    if (mult <= 5) return 'badge-green';
    if (mult <= 25) return 'badge-blue';
    if (mult <= 100) return 'badge-purple';
    return 'badge-gold';
  }

  // --- DYNAMIC SVG ZEUS LIGHTNING ENGINE ---
  function getZeusHandPosition() {
    const zeusBox = el.zeusFigureBox;
    if (!zeusBox) {
      return { x: window.innerWidth * 0.88, y: window.innerHeight * 0.35 };
    }
    const rect = zeusBox.getBoundingClientRect();
    // Posisi tangan kanan Zeus yang memegang petir di bagian atas-kiri frame Zeus
    return {
      x: rect.left + rect.width * 0.28,
      y: rect.top + rect.height * 0.22
    };
  }

  function getCellCenterPosition(cellEl) {
    if (!cellEl) return { x: window.innerWidth * 0.5, y: window.innerHeight * 0.5 };
    const rect = cellEl.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    };
  }

  // Menghasilkan jalur lintasan petir fraktal bergerigi alami
  function generateLightningPath(x1, y1, x2, y2, displacement = 32, iterations = 5) {
    let points = [{ x: x1, y: y1 }, { x: x2, y: y2 }];
    for (let i = 0; i < iterations; i++) {
      const newPoints = [];
      for (let j = 0; j < points.length - 1; j++) {
        const p1 = points[j];
        const p2 = points[j + 1];
        const midX = (p1.x + p2.x) / 2;
        const midY = (p1.y + p2.y) / 2;
        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;
        const len = Math.hypot(dx, dy);
        if (len < 1) continue;
        const nx = -dy / len;
        const ny = dx / len;
        const disp = (Math.random() - 0.5) * displacement * Math.min(1.4, len / 120);
        newPoints.push(p1);
        newPoints.push({ x: midX + nx * disp, y: midY + ny * disp });
      }
      newPoints.push(points[points.length - 1]);
      points = newPoints;
      displacement *= 0.56;
    }
    let d = `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`;
    for (let i = 1; i < points.length; i++) {
      d += ` L ${points[i].x.toFixed(1)} ${points[i].y.toFixed(1)}`;
    }
    return d;
  }

  // Menyemburkan sambaran petir SVG dinamis dari tangan Zeus ke arah sel multiplier yang sedang turun
  function shootLightningToCell(item, multVal) {
    if (!item || !item.el) return;
    const svgGroup = el.lightningSvgGroup;
    if (!svgGroup) return;

    // Pose mengangkat petir Zeus & sound effect halilintar
    if (el.zeusFigureBox) el.zeusFigureBox.classList.add('is-casting');
    AudioFX.thunderStrike();

    // Kilatan layar lembut
    if (el.lightningFlash) {
      el.lightningFlash.style.opacity = '0.35';
      setTimeout(() => {
        if (el.lightningFlash) el.lightningFlash.style.opacity = '0';
      }, 120);
    }

    const start = getZeusHandPosition();
    const end = getCellCenterPosition(item.el);

    const glowPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    glowPath.setAttribute('class', 'lightning-glow-beam');

    const corePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    corePath.setAttribute('class', 'lightning-core-beam');

    const goldPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    goldPath.setAttribute('class', 'lightning-gold-spark');

    const branchPaths = [
      document.createElementNS('http://www.w3.org/2000/svg', 'path'),
      document.createElementNS('http://www.w3.org/2000/svg', 'path')
    ];
    branchPaths.forEach(bp => bp.setAttribute('class', 'lightning-branch-beam'));

    const initialD = generateLightningPath(start.x, start.y, end.x, end.y, 35, 5);
    glowPath.setAttribute('d', initialD);
    corePath.setAttribute('d', initialD);
    goldPath.setAttribute('d', initialD);

    const midX = (start.x + end.x) / 2;
    const midY = (start.y + end.y) / 2;
    branchPaths[0].setAttribute('d', generateLightningPath(midX, midY, midX - 55, midY + 45, 22, 3));
    branchPaths[1].setAttribute('d', generateLightningPath(start.x * 0.7 + end.x * 0.3, start.y * 0.7 + end.y * 0.3, start.x * 0.7 + end.x * 0.3 + 35, start.y * 0.7 + end.y * 0.3 - 45, 20, 3));

    svgGroup.appendChild(glowPath);
    svgGroup.appendChild(corePath);
    svgGroup.appendChild(goldPath);
    branchPaths.forEach(bp => svgGroup.appendChild(bp));

    // Animasi petir melesat berjalan dari tangan Zeus menuju ke multiplier
    try {
      const totalLen = corePath.getTotalLength() || 600;
      corePath.style.strokeDasharray = totalLen;
      corePath.style.strokeDashoffset = totalLen;
      glowPath.style.strokeDasharray = totalLen;
      glowPath.style.strokeDashoffset = totalLen;
      goldPath.style.strokeDasharray = totalLen;
      goldPath.style.strokeDashoffset = totalLen;

      const animDuration = 110;
      const startTime = performance.now();

      function stepTravel(now) {
        const elapsed = now - startTime;
        const progress = Math.min(1, elapsed / animDuration);
        const currentOffset = totalLen * (1 - progress);
        corePath.style.strokeDashoffset = currentOffset;
        glowPath.style.strokeDashoffset = currentOffset;
        goldPath.style.strokeDashoffset = currentOffset;

        if (progress < 1) {
          requestAnimationFrame(stepTravel);
        } else {
          // Petir menghantam sel multiplier saat mendarat
          item.el.classList.add('lightning-struck');
          setTimeout(() => item.el && item.el.classList.remove('lightning-struck'), 600);

          if (multVal >= 100) {
            triggerVibrate(250);
            Bridge.call('vibratePhone', 250);
            if (el.gameViewport) {
              el.gameViewport.classList.add('shake-screen');
              setTimeout(() => el.gameViewport && el.gameViewport.classList.remove('shake-screen'), 350);
            }
          }

          // Animasi crackle / kedipan kilat petir selama 180ms
          let flickerCount = 0;
          const flickerInterval = setInterval(() => {
            flickerCount++;
            const newD = generateLightningPath(start.x, start.y, end.x, end.y, 25, 5);
            glowPath.setAttribute('d', newD);
            corePath.setAttribute('d', newD);
            goldPath.setAttribute('d', newD);

            if (flickerCount >= 4) {
              clearInterval(flickerInterval);
              glowPath.style.transition = 'opacity 0.15s ease-out';
              corePath.style.transition = 'opacity 0.15s ease-out';
              goldPath.style.transition = 'opacity 0.15s ease-out';
              branchPaths.forEach(bp => bp.style.transition = 'opacity 0.15s ease-out');

              glowPath.style.opacity = '0';
              corePath.style.opacity = '0';
              goldPath.style.opacity = '0';
              branchPaths.forEach(bp => bp.style.opacity = '0');

              setTimeout(() => {
                glowPath.remove();
                corePath.remove();
                goldPath.remove();
                branchPaths.forEach(bp => bp.remove());
                if (el.zeusFigureBox) el.zeusFigureBox.classList.remove('is-casting');
              }, 160);
            }
          }, 45);
        }
      }
      requestAnimationFrame(stepTravel);
    } catch (e) {
      setTimeout(() => {
        glowPath.remove();
        corePath.remove();
        goldPath.remove();
        branchPaths.forEach(bp => bp.remove());
        if (el.zeusFigureBox) el.zeusFigureBox.classList.remove('is-casting');
      }, 350);
    }
  }

  function setupOrbOnItem(item, multVal) {
    item.isOrb = true;
    item.mult = multVal;
    item.sym = { id: 'multiplier-orb', name: 'Multiplier ' + multVal + 'X', isScatter: false, basePayout: 0 };
    item.img.src = '/assets/img/winged-orb.svg';
    item.img.alt = 'Multiplier ' + multVal + 'X';
    item.img.style.visibility = 'visible';
    item.el.classList.add('orb-cell');
    item.el.classList.remove('win-highlight', 'exploding', 'empty-drop-out');

    const existingBadge = item.el.querySelector('.orb-badge-tag');
    if (existingBadge) existingBadge.remove();

    // Text multiplier berada di tengah cell (styling dikontrol oleh .orb-badge-tag)
    const badge = document.createElement('span');
    badge.className = 'orb-badge-tag ' + getBadgeColorClass(multVal);
    badge.textContent = multVal + 'X';
    item.el.appendChild(badge);

    // Akumulasi total multiplier di kiri atas (starts at 1x, accumulates)
    if (state.tumbleMultiplierSum === 1) {
      state.tumbleMultiplierSum = multVal;
    } else {
      state.tumbleMultiplierSum += multVal;
    }
    state.currentRoundMultipliers.push(multVal);
    updateDisplays();
  }

  // Alias untuk kompatibilitas
  function spawnOrbOnItem(item, multVal) {
    setupOrbOnItem(item, multVal);
    shootLightningToCell(item, multVal);
  }

  function setCellSymbol(item, sym) {
    item.sym = sym;
    item.isOrb = false;
    item.mult = 0;
    item.img.src = sym.img;
    item.img.alt = sym.name;
    item.img.style.visibility = 'visible';
    item.el.className = 'slot-cell';
    const existingBadge = item.el.querySelector('.orb-badge-tag');
    if (existingBadge) existingBadge.remove();
  }

  // --- SPIN ANIMATION: MULTIPLIER IKUT DROP SAAT SPIN BERSAMA GEM DARI ATAS ---
  async function runSpinAnimation() {
    // Stage 1: Buat semua kosong (All gems slide/drop down out of the grid)
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        item.el.classList.remove('win-highlight', 'exploding', 'spin-cascade-drop', 'tumble-drop');
        item.el.classList.add('empty-drop-out');
      }
    }
    AudioFX.spinTick();
    const emptyDelay = state.stopRequested ? 40 : Math.max(50, Math.floor(130 / state.speedMultiplier));
    await sleep(emptyDelay);

    // Set all cells to blank / empty grid (semua kosong)
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        item.el.className = 'slot-cell is-empty-grid';
        item.img.style.visibility = 'hidden';
        item.isOrb = false;
        item.mult = 0;
        const badge = item.el.querySelector('.orb-badge-tag');
        if (badge) badge.remove();
      }
    }
    const emptyPause = state.stopRequested ? 20 : Math.max(30, Math.floor(75 / state.speedMultiplier));
    await sleep(emptyPause);

    // Stage 2: Tentukan apakah ada multiplier orb yang IKUT JATUH BERSAMA GEM
    // (Tidak mengubah gem yang sudah ada di papan!)
    const plannedMultipliers = [];
    const multSpinChance = state.inFreeSpins ? 0.50 : 0.28;
    if (Math.random() < multSpinChance) {
      const count = Math.random() < (state.inFreeSpins ? 0.35 : 0.20) ? 2 : 1;
      const usedCoords = new Set();
      for (let i = 0; i < count; i++) {
        const c = Math.floor(Math.random() * 6);
        const r = Math.floor(Math.random() * 5);
        const key = `${c},${r}`;
        if (!usedCoords.has(key)) {
          usedCoords.add(key);
          const val = MULTIPLIER_VALUES[Math.floor(Math.random() * MULTIPLIER_VALUES.length)];
          plannedMultipliers.push({ col: c, row: r, val });
        }
      }
    }

    const colStagger = state.stopRequested ? 0 : Math.max(15, Math.floor(38 / state.speedMultiplier));
    for (let col = 0; col < 6; col++) {
      const orbsInThisCol = [];

      if (state.stopRequested) {
        for (let c = col; c < 6; c++) {
          for (let row = 0; row < 5; row++) {
            const item = state.board[c][row];
            const plan = plannedMultipliers.find(p => p.col === c && p.row === row);
            if (plan) {
              setupOrbOnItem(item, plan.val);
              item.el.className = 'slot-cell orb-cell spin-cascade-drop';
              shootLightningToCell(item, plan.val);
            } else {
              const sym = getRandomSymbol();
              setCellSymbol(item, sym);
              item.el.className = 'slot-cell spin-cascade-drop';
            }
          }
        }
        AudioFX.spinTick();
        break;
      }

      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        const plan = plannedMultipliers.find(p => p.col === col && p.row === row);
        if (plan) {
          setupOrbOnItem(item, plan.val);
          item.el.className = 'slot-cell orb-cell spin-cascade-drop';
          orbsInThisCol.push({ item, val: plan.val });
        } else {
          const sym = getRandomSymbol();
          setCellSymbol(item, sym);
          item.el.className = 'slot-cell spin-cascade-drop';
        }
      }
      AudioFX.spinTick();

      // Saat multiplier sedang turun, petir Zeus menyambar ke arahnya dengan animasi berjalan!
      if (orbsInThisCol.length > 0) {
        orbsInThisCol.forEach(o => {
          shootLightningToCell(o.item, o.val);
        });
      }

      if (colStagger > 0) {
        await sleep(colStagger);
      }
    }

    const settleDelay = state.stopRequested ? 50 : Math.max(60, Math.floor(200 / state.speedMultiplier));
    await sleep(settleDelay);

    // Clean up animation classes to normal slot-cell / orb-cell
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        item.el.className = item.isOrb ? 'slot-cell orb-cell' : 'slot-cell';
      }
    }
  }

  // --- EVALUATE CLUSTERS & TUMBLE CASCADE ---
  async function evaluateClusters() {
    const symbolCounts = {};
    const symbolPositions = {};

    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        const item = state.board[col][row];
        // MULTIPLIER ORB TIDAK DIHITUNG DALAM KOMBINASI PECAH BIASA
        if (!item.isOrb && item.sym && !item.sym.isScatter && item.sym.id !== 'multiplier-orb') {
          const id = item.sym.id;
          symbolCounts[id] = (symbolCounts[id] || 0) + 1;
          if (!symbolPositions[id]) symbolPositions[id] = [];
          symbolPositions[id].push({ col, row });
        }
      }
    }

    // Find symbols with >= 8 items
    const winningIds = Object.keys(symbolCounts).filter(id => symbolCounts[id] >= 8);
    if (winningIds.length === 0) {
      return false;
    }

    let cascadeSubtotal = 0;
    const bet = getCurrentBet();

    winningIds.forEach(id => {
      const count = symbolCounts[id];
      const sym = SYMBOLS.find(s => s.id === id);
      let tierMultiplier = 1.0;
      if (count >= 12) tierMultiplier = 3.2;
      else if (count >= 10) tierMultiplier = 1.8;
      const payout = Math.floor(bet * (sym.basePayout / 40) * tierMultiplier);
      cascadeSubtotal += payout;

      // Log into Breakdown
      state.roundBreakdown.push({ count, sym, payout });

      // Highlight winning cells (Multiplier Orb tidak ikut di-highlight)
      symbolPositions[id].forEach(pos => {
        const cellItem = state.board[pos.col][pos.row];
        if (!cellItem.isOrb) {
          cellItem.el.classList.add('win-highlight');
        }
      });
    });

    state.currentTumbleWin += cascadeSubtotal;
    if (el.tumbleWinVal) el.tumbleWinVal.textContent = formatNumber(state.currentTumbleWin);
    renderBreakdown();

    AudioFX.winChime();
    triggerVibrate(35);

    const highlightDelay = state.stopRequested ? 80 : Math.max(90, Math.floor(450 / state.speedMultiplier));
    await sleep(highlightDelay);

    // Explode winning cells (MULTIPLIER ORB TIDAK IKUT PECAH!)
    winningIds.forEach(id => {
      symbolPositions[id].forEach(pos => {
        const cellItem = state.board[pos.col][pos.row];
        if (!cellItem.isOrb) {
          cellItem.el.classList.add('exploding');
        }
      });
    });

    AudioFX.tumbleExplode();
    const explodeDelay = state.stopRequested ? 60 : Math.max(70, Math.floor(300 / state.speedMultiplier));
    await sleep(explodeDelay);

    // Column gravity drop:
    // Multiplier orbs yang didapat pada saat tumble TIDAK IKUT PECAH melainkan TETAP DISITU
    for (let col = 0; col < 6; col++) {
      const survivors = [];
      for (let row = 4; row >= 0; row--) {
        const item = state.board[col][row];
        if (item.isOrb || !item.el.classList.contains('exploding')) {
          survivors.push({
            sym: item.sym,
            isOrb: item.isOrb,
            mult: item.mult
          });
        }
      }

      for (let row = 4; row >= 0; row--) {
        const item = state.board[col][row];
        item.el.className = 'slot-cell tumble-drop';
        const existingBadge = item.el.querySelector('.orb-badge-tag');
        if (existingBadge) existingBadge.remove();

        const sIdx = 4 - row;
        if (sIdx < survivors.length) {
          const s = survivors[sIdx];
          item.sym = s.sym;
          item.isOrb = s.isOrb;
          item.mult = s.mult;
          item.img.src = s.isOrb ? '/assets/img/winged-orb.svg' : s.sym.img;
          item.img.alt = s.isOrb ? ('Multiplier ' + s.mult + 'X') : s.sym.name;
          item.img.style.visibility = 'visible';

          // Jika simbol yang bertahan adalah Multiplier Orb, pertahankan status dan badge orb-nya di tengah!
          if (s.isOrb) {
            item.el.classList.add('orb-cell');
            const b = document.createElement('span');
            b.className = 'orb-badge-tag ' + getBadgeColorClass(s.mult);
            b.textContent = s.mult + 'X';
            item.el.appendChild(b);
          }
        } else {
          // New symbol drops from above to fill empty space
          const orbDropChance = state.inFreeSpins ? 0.035 : 0.015;
          if (Math.random() < orbDropChance) {
            const multVal = MULTIPLIER_VALUES[Math.floor(Math.random() * MULTIPLIER_VALUES.length)];
            setupOrbOnItem(item, multVal);
            item.el.classList.add('orb-cell');
            shootLightningToCell(item, multVal);
          } else {
            const newSym = getRandomSymbol();
            setCellSymbol(item, newSym);
          }
        }
      }
    }

    const dropDelay = state.stopRequested ? 80 : Math.max(80, Math.floor(320 / state.speedMultiplier));
    await sleep(dropDelay);
    return true;
  }

  // --- POPUP FREESPIN 10 (Overlay saat mendapatkan 4+ Scatter) ---
  let freespinIntroResolver = null;
  function showFreeSpinsIntroModal(count = 10) {
    return new Promise(resolve => {
      freespinIntroResolver = resolve;
      state.celebrationActive = true;
      AudioFX.bigFanfare();
      const overlay = document.getElementById('freespin-intro-overlay');
      if (overlay) {
        overlay.style.display = 'flex';
      }
      triggerFreeSpins(count);
    });
  }

  function startFreeSpinsFromPopup() {
    AudioFX.buttonClick();
    const overlay = document.getElementById('freespin-intro-overlay');
    if (overlay) {
      overlay.style.display = 'none';
    }
    state.celebrationActive = false;
    if (typeof freespinIntroResolver === 'function') {
      const res = freespinIntroResolver;
      freespinIntroResolver = null;
      res();
    }
  }

  // --- SCATTER CHECK ---
  async function checkScatterBonus() {
    let scatters = 0;
    for (let col = 0; col < 6; col++) {
      for (let row = 0; row < 5; row++) {
        if (state.board[col][row].sym && state.board[col][row].sym.isScatter) {
          scatters++;
        }
      }
    }

    if (scatters >= 4) {
      AudioFX.scatterDing();
      const bet = getCurrentBet();
      let bonusPayout = bet * (scatters === 4 ? 3 : (scatters === 5 ? 5 : 100));
      state.coins += bonusPayout;
      updateDisplays();

      if (state.inFreeSpins) {
        state.freeSpinsRemaining += 5;
        state.freeSpinsTotalAllocated += 5;
        updateDisplays();
        alert('⚡ RETRIGGER! +5 FREE SPIN DITAMBAHKAN! ⚡');
      } else {
        await showFreeSpinsIntroModal(10);
      }
    }
  }

  function triggerFreeSpins(count = 10) {
    state.inFreeSpins = true;
    state.freeSpinsTotalAllocated = count;
    state.freeSpinsRemaining = count;
    state.freeSpinsTotalWin = 0;
    state.accumulatedGlobalMultiplier = 1;
    state.tumbleMultiplierSum = 1;
    updateDisplays();
    Bridge.call('onFreeSpinsTriggered', count);
  }

  function buyFreeSpinsDirect() {
    if (state.isSpinning) return;
    const cost = getCurrentBet() * 100;
    if (state.coins < cost) {
      alert('Chip Anda tidak cukup untuk Membeli Free Spin (Perlu ' + formatNumber(cost) + ' Chip)!');
      return;
    }
    if (confirm('Beli 10 Free Spin seharga ' + formatNumber(cost) + ' Chip?')) {
      state.coins -= cost;
      Bridge.call('onBet', cost);
      Bridge.call('updateCoins', -cost);
      showFreeSpinsIntroModal(10);
      executeSpin(true);
    }
  }

  // =========================================================================
  // CELEBRATION TIERS & ANIMATED POPUP ENGINE
  // =========================================================================
  function determineCelebrationTier(amount, isFreeSpinEnd = false, freeSpinRounds = 0) {
    if (isFreeSpinEnd) {
      return {
        title: 'SELESAI FREE SPIN!',
        subtitle: 'TOTAL KEMENANGAN ' + (freeSpinRounds || 10) + ' PUTARAN',
        emblem: '👑',
        tierClass: 'tier-freespin'
      };
    }
    const bet = getCurrentBet() || 1;
    const mult = amount / bet;

    if (mult >= 1000) {
      return {
        title: 'MAX WIN!',
        subtitle: 'KEMENANGAN MAKSIMAL PETIR ZEUS!',
        emblem: '⚡👑⚡',
        tierClass: 'tier-max'
      };
    } else if (mult >= 500) {
      return {
        title: 'MASSIVE WIN!',
        subtitle: 'KEMENANGAN DAHSYAT OLYMPUS!',
        emblem: '🏛️💎',
        tierClass: 'tier-massive'
      };
    } else if (mult >= 250) {
      return {
        title: 'EPIC WIN!',
        subtitle: 'KEMENANGAN LEGENDA DEWA!',
        emblem: '🔥⚔️',
        tierClass: 'tier-epic'
      };
    } else if (mult >= 100) {
      return {
        title: 'SUPER WIN!',
        subtitle: 'KEMENANGAN LUAR BIASA!',
        emblem: '✨⚡',
        tierClass: 'tier-super'
      };
    } else if (mult >= 50) {
      return {
        title: 'MEGA WIN!',
        subtitle: 'KEMENANGAN BESAR!',
        emblem: '💰👑',
        tierClass: 'tier-mega'
      };
    } else if (mult >= 20) {
      return {
        title: 'BIG WIN!',
        subtitle: 'KEMENANGAN BESAR!',
        emblem: '🪙✨',
        tierClass: 'tier-big'
      };
    }
    return null;
  }

  // --- CELEBRATION CANVAS PARTICLES (GOLD COINS & SPARKS) ---
  const CelebrationFX = {
    canvas: null,
    ctx: null,
    particles: [],
    animId: null,

    init() {
      this.canvas = document.getElementById('celebration-coins-canvas');
      if (this.canvas) {
        this.ctx = this.canvas.getContext('2d');
      }
    },

    resize() {
      if (!this.canvas) return;
      this.canvas.width = window.innerWidth;
      this.canvas.height = window.innerHeight;
    },

    start() {
      this.init();
      if (!this.canvas || !this.ctx) return;
      this.resize();
      this.particles = [];
      const count = Math.min(50, Math.max(25, Math.floor(window.innerWidth / 20)));

      for (let i = 0; i < count; i++) {
        this.particles.push({
          x: Math.random() * this.canvas.width,
          y: -20 - Math.random() * (this.canvas.height * 0.7),
          radius: 9 + Math.random() * 11,
          speedY: 3.5 + Math.random() * 4.5,
          speedX: (Math.random() - 0.5) * 3,
          rotation: Math.random() * Math.PI * 2,
          rotSpeed: 0.05 + Math.random() * 0.08,
          color: Math.random() > 0.35 ? '#ffd700' : '#f59e0b',
          isSpark: Math.random() < 0.3
        });
      }

      const loop = () => {
        if (!state.celebrationActive) return;
        this.render();
        this.animId = requestAnimationFrame(loop);
      };
      this.animId = requestAnimationFrame(loop);
    },

    render() {
      if (!this.ctx || !this.canvas) return;
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

      for (let p of this.particles) {
        p.y += p.speedY;
        p.x += p.speedX;
        p.rotation += p.rotSpeed;

        if (p.y > this.canvas.height + 30) {
          p.y = -20;
          p.x = Math.random() * this.canvas.width;
        }

        this.ctx.save();
        this.ctx.translate(p.x, p.y);
        this.ctx.rotate(p.rotation);

        if (p.isSpark) {
          this.ctx.fillStyle = '#ffffff';
          this.ctx.shadowColor = '#00e5ff';
          this.ctx.shadowBlur = 8;
          this.ctx.beginPath();
          this.ctx.moveTo(0, -p.radius);
          this.ctx.lineTo(p.radius * 0.3, -p.radius * 0.3);
          this.ctx.lineTo(p.radius, 0);
          this.ctx.lineTo(p.radius * 0.3, p.radius * 0.3);
          this.ctx.lineTo(0, p.radius);
          this.ctx.lineTo(-p.radius * 0.3, p.radius * 0.3);
          this.ctx.lineTo(-p.radius, 0);
          this.ctx.lineTo(-p.radius * 0.3, -p.radius * 0.3);
          this.ctx.closePath();
          this.ctx.fill();
        } else {
          const yScale = Math.abs(Math.cos(p.rotation));
          this.ctx.scale(1, Math.max(0.2, yScale));
          this.ctx.beginPath();
          this.ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
          this.ctx.fillStyle = p.color;
          this.ctx.shadowColor = '#ffd700';
          this.ctx.shadowBlur = 6;
          this.ctx.fill();

          this.ctx.beginPath();
          this.ctx.arc(0, 0, p.radius * 0.72, 0, Math.PI * 2);
          this.ctx.strokeStyle = '#fffbeb';
          this.ctx.lineWidth = 1.2;
          this.ctx.stroke();

          this.ctx.fillStyle = '#ffffff';
          this.ctx.font = 'bold ' + Math.floor(p.radius * 0.8) + 'px sans-serif';
          this.ctx.textAlign = 'center';
          this.ctx.textBaseline = 'middle';
          this.ctx.fillText('🪙', 0, 0);
        }

        this.ctx.restore();
      }
    },

    stop() {
      if (this.animId) {
        cancelAnimationFrame(this.animId);
        this.animId = null;
      }
      if (this.ctx && this.canvas) {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      }
    }
  };

  window.addEventListener('resize', () => {
    if (state.celebrationActive) {
      CelebrationFX.resize();
    }
  });

  // --- CELEBRATION MODAL DISPLAY & PAUSE PROMISE ---
  let celebrationCountAnim = null;
  let celebrationAutoDismissTimer = null;

  function showCelebrationModal(amount, tierInfo) {
    return new Promise((resolve) => {
      state.celebrationActive = true;
      state.celebrationResolver = resolve;

      const overlay = el.celebrationOverlay;
      const titleEl = el.celebrationTitle;
      const subtitleEl = el.celebrationSubtitle;
      const amountEl = el.celebrationAmount;
      const emblemEl = el.celebrationEmblem;
      const cardBox = el.celebrationCardBox;

      if (!overlay || !amountEl) {
        state.celebrationActive = false;
        resolve();
        return;
      }

      if (titleEl) {
        titleEl.textContent = tierInfo.title;
        titleEl.className = 'celebration-title ' + (tierInfo.tierClass || 'tier-big');
      }
      if (emblemEl) {
        emblemEl.textContent = tierInfo.emblem || '👑';
      }
      if (subtitleEl) {
        if (tierInfo.subtitle) {
          subtitleEl.textContent = tierInfo.subtitle;
          subtitleEl.style.display = 'block';
        } else {
          subtitleEl.style.display = 'none';
        }
      }

      amountEl.textContent = '+0';

      if (cardBox) {
        cardBox.style.animation = 'none';
        void cardBox.offsetWidth;
        cardBox.style.animation = 'zoomPopCelebration 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
      }

      overlay.style.display = 'flex';
      CelebrationFX.start();
      AudioFX.bigFanfare();
      triggerVibrate(120);

      const duration = 2400;
      const startTime = performance.now();
      let lastSoundTick = 0;

      function stepCount(now) {
        if (!state.celebrationActive) return;
        const elapsed = now - startTime;
        const progress = Math.min(1, elapsed / duration);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const currentVal = Math.floor(amount * easeOut);

        amountEl.textContent = '+' + formatNumber(currentVal);

        if (now - lastSoundTick > 75 && progress < 1) {
          AudioFX.coinTick();
          lastSoundTick = now;
        }

        if (progress < 1) {
          celebrationCountAnim = requestAnimationFrame(stepCount);
        } else {
          amountEl.textContent = '+' + formatNumber(amount);
          AudioFX.celebrationCheer();
          triggerVibrate(80);

          celebrationAutoDismissTimer = setTimeout(() => {
            finishCelebration();
          }, 3000);
        }
      }

      celebrationCountAnim = requestAnimationFrame(stepCount);
    });
  }

  function skipCelebration() {
    AudioFX.buttonClick();
    triggerVibrate(30);
    finishCelebration();
  }

  function dismissCelebration() {
    AudioFX.buttonClick();
    triggerVibrate(30);
    finishCelebration();
  }

  function finishCelebration() {
    if (!state.celebrationActive) return;
    state.celebrationActive = false;
    if (celebrationCountAnim) {
      cancelAnimationFrame(celebrationCountAnim);
      celebrationCountAnim = null;
    }
    if (celebrationAutoDismissTimer) {
      clearTimeout(celebrationAutoDismissTimer);
      celebrationAutoDismissTimer = null;
    }
    CelebrationFX.stop();
    if (el.celebrationOverlay) {
      el.celebrationOverlay.style.display = 'none';
    }
    if (typeof state.celebrationResolver === 'function') {
      const resolve = state.celebrationResolver;
      state.celebrationResolver = null;
      resolve();
    }
  }

  // --- TOP MENU (SOUND, VIBRATION, LOBBY) ---
  function toggleTopMenu() {
    const dropdown = el.topMenuDropdown;
    if (!dropdown) return;
    const isShowing = dropdown.style.display === 'flex';
    dropdown.style.display = isShowing ? 'none' : 'flex';
    AudioFX.spinTick();
  }

  function toggleSound() {
    state.soundEnabled = !state.soundEnabled;
    const badge = document.getElementById('menu-sound-badge');
    const icon = document.getElementById('menu-sound-icon');
    if (badge) {
      badge.textContent = state.soundEnabled ? 'ON' : 'OFF';
      badge.className = 'item-toggle-badge' + (state.soundEnabled ? '' : ' is-off');
    }
    if (icon) {
      icon.textContent = state.soundEnabled ? '🔊' : '🔇';
    }
    if (state.soundEnabled) AudioFX.spinTick();
  }

  function toggleVibration() {
    state.vibrationEnabled = !state.vibrationEnabled;
    const badge = document.getElementById('menu-vibe-badge');
    const icon = document.getElementById('menu-vibe-icon');
    if (badge) {
      badge.textContent = state.vibrationEnabled ? 'ON' : 'OFF';
      badge.className = 'item-toggle-badge' + (state.vibrationEnabled ? '' : ' is-off');
    }
    if (icon) {
      icon.textContent = state.vibrationEnabled ? '📳' : '📴';
    }
    if (state.vibrationEnabled) triggerVibrate(50);
  }

  function exitGame() {
    if (el.topMenuDropdown) el.topMenuDropdown.style.display = 'none';
    if (Bridge.has() && typeof window.AndroidBridge.closeGame === 'function') {
      Bridge.call('closeGame');
    } else {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        alert('Kembali ke Lobby Kasino.');
      }
    }
  }

  function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.style.display = 'none';
  }

  // Close menus on outside click
  window.addEventListener('click', function (e) {
    const menuWrap = document.querySelector('.top-menu-wrapper');
    if (menuWrap && !menuWrap.contains(e.target) && el.topMenuDropdown) {
      el.topMenuDropdown.style.display = 'none';
    }
    const spinContainer = document.querySelector('.spin-button-container');
    if (spinContainer && !spinContainer.contains(e.target) && el.autoSpinPopup) {
      el.autoSpinPopup.style.display = 'none';
    }
  });

  // =========================================================================
  // OLIVERA CASINO SPECIFICATION: CALLBACKS & GLOBAL WINDOW EXPORTS
  // =========================================================================

  // [CB 01] UPDATE SALDO KOIN SECARA REALTIME
  window.setPlayerCoins = function (coins) {
    const c = Number(coins) || 0;
    state.coins = c;
    const chipDisp = document.getElementById('chip-disp');
    if (chipDisp) {
      chipDisp.textContent = '🪙 ' + c.toLocaleString('id-ID');
    }
    const playerChips = document.getElementById('player-chips');
    if (playerChips) {
      playerChips.textContent = formatNumber(c);
    }
    updateDisplays();
  };

  // [CB 02] UPDATE PROFIL PEMAIN SECARA REALTIME
  window.setPlayerProfile = function (profileJson) {
    try {
      const p = (typeof profileJson === 'string') ? JSON.parse(profileJson) : profileJson;
      if (!p) return;
      if (p.displayName) {
        state.playerName = p.displayName;
        const nameEl = document.getElementById('player-name');
        if (nameEl) nameEl.textContent = p.displayName;
      }
      if (p.vipString) {
        state.vipString = p.vipString;
        const vipEl = document.getElementById('player-vip');
        if (vipEl) vipEl.textContent = p.vipString;
      } else if (p.vipLevel !== undefined && p.vipLevel !== null) {
        state.vipString = 'VIP' + p.vipLevel;
        const vipEl = document.getElementById('player-vip');
        if (vipEl) vipEl.textContent = state.vipString;
      }
      if (p.playerLevel !== undefined && p.playerLevel !== null) {
        state.playerLevel = p.playerLevel;
        const lvlEl = document.getElementById('player-level');
        if (lvlEl) lvlEl.textContent = p.playerLevel;
      }
      const infoEl = document.getElementById('player-info');
      if (infoEl) {
        infoEl.textContent = (p.displayName || 'Player') + ' | ' + (p.vipString || 'VIP0') + ' | Lv ' + (p.playerLevel || 1);
      }
      if (p.chipBalance !== undefined && p.chipBalance !== null) {
        window.setPlayerCoins(p.chipBalance);
      }
      if (p.avatarUrl && p.avatarUrl.trim() !== '') {
        const avatarImg = document.getElementById('player-avatar-img');
        if (avatarImg) avatarImg.src = p.avatarUrl;
      }
    } catch (e) {
      console.warn('[OliveraCasino] Error parsing player profile:', e);
    }
  };

  // [CB 03] UPDATE PROGRESSIVE JACKPOT SECARA REALTIME
  window.onJackpotUpdate = function (jackpotAmount) {
    const jp = Number(jackpotAmount) || 0;
    state.jackpot = jp;
    const jpDisp = document.getElementById('jackpot-disp');
    if (jpDisp) {
      jpDisp.textContent = 'JP ' + jp.toLocaleString('id-ID');
    }
    const jpAlt = document.getElementById('jackpot-display');
    if (jpAlt) {
      jpAlt.textContent = formatNumber(jp);
    }
  };

  // [CB 04] CALLBACK SAAT POPUP / FRAGMENT NATIVE DITUTUP
  window.onPopupClosed = function (popupName, currentCoins) {
    console.log('[OliveraCasino] Popup ' + popupName + ' ditutup. Saldo chip saat ini: ' + currentCoins);
    if (currentCoins !== undefined && currentCoins !== null && !isNaN(Number(currentCoins))) {
      window.setPlayerCoins(Number(currentCoins));
    }
  };

  // [ID 12 & ID 13] Global window triggers for Open Profile & Open Store
  window.openProfileDialog = openProfileDialog;
  window.openProfileInfo = openProfileDialog;
  window.openProfile = openProfileDialog;
  window.openStoreDialog = openStoreDialog;
  window.openStore = openStoreDialog;
  window.openToko = openStoreDialog;

  // [ID 01 / ID 02] Template spinSlot convenience method
  window.spinSlot = function (bet) {
    if (typeof bet === 'number' && bet > 0) {
      const idx = BET_LEVELS.indexOf(bet);
      if (idx !== -1) {
        state.betIndex = idx;
      }
    }
    handleSpinAction();
  };

  window.setBet = function (amount) {
    const idx = BET_LEVELS.indexOf(amount);
    if (idx !== -1) {
      state.betIndex = idx;
      updateDisplays();
    }
  };

  window.updateDisplays = updateDisplays;
  window.adjustBet = adjustBet;
  window.startSpin = handleSpinAction;
  window.handleSpinAction = handleSpinAction;
  window.triggerZeusLightning = function(multVal = 100) {
    const orbCells = [];
    for (let c = 0; c < 6; c++) {
      for (let r = 0; r < 5; r++) {
        if (state.board[c][r].isOrb) orbCells.push(state.board[c][r]);
      }
    }
    const target = orbCells.length > 0 
      ? orbCells[Math.floor(Math.random() * orbCells.length)]
      : state.board[Math.floor(Math.random() * 6)][Math.floor(Math.random() * 5)];
    shootLightningToCell(target, multVal);
  };
  window.manualLightningStrike = (val = 500) => window.triggerZeusLightning(val);
  window.shootLightningToCell = shootLightningToCell;
  window.evaluateClusters = evaluateClusters;
  window.showCelebration = showCelebrationModal;
  window.dismissCelebration = dismissCelebration;
  window.skipCelebration = skipCelebration;
  window.startFreeSpinsFromPopup = startFreeSpinsFromPopup;
  window.showFreeSpinsIntroModal = showFreeSpinsIntroModal;

  window.testFreespin10Popup = async function () {
    closeModal('paytable-modal');
    closeModal('chat-modal');
    await showFreeSpinsIntroModal(10);
  };

  window.testCelebration = async function (tierType) {
    closeModal('paytable-modal');
    closeModal('chat-modal');
    const bet = getCurrentBet() || 30000;
    let amt = bet * 25;
    let isFs = false;
    let rounds = 10;
    switch (tierType) {
      case 'big':
        amt = bet * 25;
        break;
      case 'mega':
        amt = bet * 60;
        break;
      case 'super':
        amt = bet * 125;
        break;
      case 'epic':
        amt = bet * 300;
        break;
      case 'massive':
        amt = bet * 600;
        break;
      case 'max':
        amt = bet * 1200;
        break;
      case 'freespin':
        amt = bet * 850;
        isFs = true;
        rounds = 10;
        break;
      default:
        amt = bet * 25;
    }
    const tier = determineCelebrationTier(amt, isFs, rounds);
    await showCelebrationModal(amt, tier);
  };

  window.exitGame = exitGame;
  window.closeModal = closeModal;
  window.buyFreeSpinsDirect = buyFreeSpinsDirect;
  window.cycleSpeed = cycleSpeed;
  window.selectAutoSpin = selectAutoSpin;
  window.toggleTopMenu = toggleTopMenu;
  window.toggleSound = toggleSound;
  window.toggleVibration = toggleVibration;

  window.openPaytable = function () {
    if (el.paytableModal) el.paytableModal.style.display = 'flex';
  };

  window.openChatInfo = function () {
    if (el.chatModal) el.chatModal.style.display = 'flex';
  };

  window.openBetModal = openBetModal;
  window.addDemoCoins = addDemoCoins;

  // --- KEYBOARD SHORTCUTS ---
  window.addEventListener('keydown', function (e) {
    if (e.code === 'Space' || e.key === ' ' || e.code === 'Enter') {
      e.preventDefault();
      handleSpinAction();
    }
  });

  // --- INIT & ANDROID BRIDGE SYNC ON LOAD (Olivera Casino Standard) ---
  window.addEventListener('DOMContentLoaded', function () {
    bindSpinLongPress();

    if (Bridge.has()) {
      try {
        // [ID 04] Get initial coin balance
        if (typeof window.AndroidBridge.getCoins === 'function') {
          const c = window.AndroidBridge.getCoins();
          if (c !== undefined && c !== null && !isNaN(Number(c)) && Number(c) >= 0) {
            window.setPlayerCoins(Number(c));
          }
        }

        // [ID 05] Get player profile JSON
        if (typeof window.AndroidBridge.getPlayerProfile === 'function') {
          const profile = window.AndroidBridge.getPlayerProfile();
          if (profile) {
            window.setPlayerProfile(profile);
          }
        } else {
          if (typeof window.AndroidBridge.getPlayerLevel === 'function') {
            const lvl = window.AndroidBridge.getPlayerLevel();
            if (typeof lvl === 'number') {
              state.playerLevel = lvl;
              const lvlEl = document.getElementById('player-level');
              if (lvlEl) lvlEl.textContent = lvl;
            }
          }
          if (typeof window.AndroidBridge.getVipString === 'function') {
            const vip = window.AndroidBridge.getVipString();
            if (vip) {
              state.vipString = vip;
              const vipEl = document.getElementById('player-vip');
              if (vipEl) vipEl.textContent = vip;
            }
          }
        }

        // [ID 09] Get initial jackpot
        if (typeof window.AndroidBridge.getJackpot === 'function') {
          const jp = window.AndroidBridge.getJackpot('gates_of_olympus');
          if (jp !== undefined && jp !== null && !isNaN(Number(jp)) && Number(jp) > 0) {
            window.onJackpotUpdate(Number(jp));
          }
        }

        if (typeof window.AndroidBridge.getBetAmount === 'function') {
          const b = window.AndroidBridge.getBetAmount();
          if (typeof b === 'number' && b > 0) {
            const bIdx = BET_LEVELS.indexOf(b);
            if (bIdx !== -1) state.betIndex = bIdx;
          }
        }
      } catch (e) {
        console.warn('[OliveraCasino] Bridge init warning:', e);
      }
    }

    initBoard();
    updateDisplays();

    // Signal ready to Android container
    Bridge.call('onGameReady');
  });
})();
